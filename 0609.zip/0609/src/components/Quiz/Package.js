import React from 'react';
import { Link } from 'react-router-dom';
import { decorate, observable, action } from 'mobx';
import PropTypes from 'prop-types';
import {observer} from "mobx-react"
import axios from 'axios';


const Title = {
    fontSize: '1.5rem',
    fontWeight: '500',
    color: '#ef5d62',
    paddingTop:'20px',
    paddingBottom: '30px',
    background: 'white',
    textAlign: 'center'
}

const Title2 = {
    fontSize: '1.5rem',
    fontWeight: '500',
    color: 'white',
    paddingTop:'20px',
    paddingBottom: '30px',
    background: 'rgb(202, 202, 202)',
    textAlign: 'center'
}

const Title3 = {
    fontSize: '1.5rem',
    fontWeight: '500',
    color: 'rgb(130, 230, 105)',
    paddingTop:'20px',
    paddingBottom: '30px',
    background: 'white',
    textAlign: 'center'
}

const Wrapper = {
    marginTop: '1rem',
    width: '220px',
    height: '220px',
    background: 'white'
}


const Wrapper2 = {
    marginTop: '1rem',
    width: '220px',
    height: '220px',
    background: 'white',
    border: '2px rgb(255, 106, 106) solid'
}

const Wrapper3 = {
    marginTop: '1rem',
    width: '220px',
    height: '220px',
    background: 'rgb(202, 202, 202)'
}

const Label = {
    fontSize: '1rem',
    color: 'gray',
    marginBottom: '0.25rem',
    textAlign: 'center'
}

const Label2 = {
    background: 'rgb(202, 202, 202)',
    fontSize: '1rem',
    color: 'white',
    marginBottom: '0.25rem',
    textAlign: 'center'
}

class Package extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            checked : false
        };

        this.session = this.props.username;
        this.email = '';
        this.bool = false;
        this.exist = false;

        this.handleCheck = this.handleCheck.bind(this);
        this.handleCheck2 = this.handleCheck2.bind(this);
    }
    
    componentDidMount() {
        axios.get('/api/board/packageClick',{
            params: {
                num: this.props.num
            }
        })
		.then((response) => {
            this.email = response.data.package[0].id;
            if(this.email==this.session){
                this.bool = true;
            }else{
                this.bool = false;
            }
		})
		.catch((err)=>{
			console.log('Error fetching packageClick',err);
        });

        let num = this.props.num;
        let id = this.props.username;
        
        axios.post('/api/board/existResult',{num, id})
		.then((response) => {
            if(response.data.result.length!=0){
                this.exist = true;
            }
		})
		.catch((err)=>{
			console.log('Error fetching packageClick',err);
        });
    }

    handleCheck() {
        const { deleteFunction, arrayNum } = this.props;

        this.setState({checked: !this.state.checked});

        deleteFunction(arrayNum);
    }

    handleCheck2() {
        const { copyFunction, num, arrayNum } = this.props;

        copyFunction(num, arrayNum);
    }

    render() {
        const { num, arrayNum, deleteMode, copyMode, username } = this.props;
        let link_read = '/quiz/read/' + num ;
        let link_save = '/quiz/quizList/' + num ;
        let link_result = '/quiz/ResultList/' + num + '/' + username;
            const packageView = (
                <div>
                    <div style={Wrapper} className="card-1">
                        <div style={Title}><b>{this.props.packageName}</b></div>
                        <div style={Label}>{this.props.content}</div>
                    </div>
                </div>
            );

            const resultpackageView = (
                <div>
                    <div style={Wrapper} className="card-1">
                        <div style={Title3}><b>{this.props.packageName}</b></div>
                        <div style={Label}>{this.props.content}</div>
                    </div>
                </div>
            );

            const deletePackageView = (
                <div>
                    {this.bool?
                    <div onClick={this.handleCheck}>
                        {this.state.checked?
                        <div style={Wrapper2} className="card-1">
                            <div style={Title}><b>{this.props.packageName}</b></div>
                            <div style={Label}>{this.props.content}</div>
                        </div>
                        :
                        <div>
                            {packageView}
                        </div>
                        }
                    </div>
                    :
                    <div style={Wrapper3} className="card-1">
                        <div style={Title2}><b>{this.props.packageName}</b></div>
                        <div style={Label2}>{this.props.content}</div>
                    </div>
                    }
                </div>
            );

            const copyPackageView = (
                <div>
                    {this.bool?
                    <div onClick={this.handleCheck2}>
                        {this.props.copySelect[arrayNum].select ?
                        <div style={Wrapper2} className="card-1">
                            <div style={Title}><b>{this.props.packageName}</b></div>
                            <div style={Label}>{this.props.content}</div>
                        </div>
                        :
                        <div>
                            {packageView}
                        </div>
                        }
                    </div>
                    :
                    <div style={Wrapper3} className="card-1">
                        <div style={Title2}><b>{this.props.packageName}</b></div>
                        <div style={Label2}>{this.props.content}</div>
                    </div>
                    }
                </div>
            );

        return (
            <div className="grid4 col" style={{background:'rgb(240, 233, 233)'}}>
                { deleteMode || copyMode ? 
                <div style={{background:'rgb(240, 233, 233)'}}>
                    { deleteMode ? deletePackageView : copyPackageView }
                </div>
                :
                <Link to={ this.bool ? link_save : this.exist ? link_result : link_read }>
                    {this.exist ? resultpackageView : packageView}
                </Link>
                }
            </div>
        );
    }
}

Package.propTypes = {
    deleteMode: PropTypes.bool,
    copyMode: PropTypes.bool,
    deleteFunction: PropTypes.func,
    copyFunction: PropTypes.func
};
 
Package.defaultProps = {
    deleteMode:false,
    copyMode:false,
    deleteFunction: (key) => { console.error("deleteFunction function not defined"); },
    copyFunction: (num, arrayNum) => { console.error("deleteFunction function not defined"); }
};

decorate(Package, {
    email: observable,
    session: observable,
    bool: observable,
    exist: observable,
    handleCheck: action
  })

export default observer(Package);