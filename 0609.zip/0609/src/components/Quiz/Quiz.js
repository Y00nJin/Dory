import React from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';
import { autorun } from 'mobx';
import PropTypes from 'prop-types';

const Title = {
    fontSize: '1rem',
    color: '#ef5d62',
    textAlign: 'center',
    display: 'inline-block',
    transform: 'translate(0,50%)'
}

const Wrapper = {
    marginTop: '1.5rem',
    width: '400px',
    height: '60px',
    background: 'white',
    display: 'inline-block'
}

const Wrapper2 = {
    marginTop: '1.5rem',
    width: '400px',
    height: '60px',
    background: 'white',
    border: '2px rgb(255, 106, 106) solid',
    display: 'inline-block'
}

const Wrapper3 = {
    marginTop: '1.5rem',
    width: '400px',
    height: '60px',
    background: 'rgb(202, 202, 202)',
    display: 'inline-block'
}

const Wrapper4 = {
    marginTop: '1.5rem',
    marginLeft: '1.5rem',
    width: '150px',
    height: '60px',
    background: 'white',
    display: 'inline-block'
}

const Label = {
    fontSize: '1rem',
    color: 'gray',
    textAlign: 'center',
    display: 'inline-block',
    transform: 'translate(0,50%)'
}

class Quiz extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            bool : false,
            tagArray: [],
            checked : false
        }

        this.handleCheck = this.handleCheck.bind(this);
        this.tagClick = this.tagClick.bind(this);

    }

    componentDidMount() {
        const { num, username } = this.props;
        const dbnum = num;
        axios.post('/api/board/selectQuiz',{dbnum})
		.then((response) => {
            const id = response.data.quiz[0].id
            if(id==username){
                this.setState({
                    bool : true 
                });
            }
		})
		.catch((err)=>{
			console.log('Error fetching packageClick',err);
        });

        let tag = this.props.tag;
        tag = tag.replace(/(\s*)/g,"");
        tag = tag.substring(1);
        let splitTag = tag.split('#');

        this.setState({
            tagArray: splitTag
        });
    }

    handleCheck() {
        const { deleteFunction, arrayNum } = this.props;

        this.setState({checked: !this.state.checked});

        deleteFunction(arrayNum);
    }

    tagClick(data) {
        const { tagC } = this.props;

        tagC(data);
    }

    render() {
        const { num, username, deleteMode } = this.props;
        let link_save = '/quiz/singleQuiz/' + num + '/' + username;
        let link_read = '/quiz/singleRead/' + num + '/' + username;
        const QuizView = (
            <div style={Wrapper} className="card-3">
                <div style={Title}><b>{this.props.quizName}</b></div>   
            </div>
        );

        const deleteView = (
            <div style={{display: 'inline-block'}}>
                {this.state.bool?
                <div onClick={this.handleCheck} style={{display: 'inline-block'}}>
                    {this.state.checked?
                    <div style={Wrapper2} className="card-3">
                        <div style={Title}><b>{this.props.quizName}</b></div>
                    </div>
                    :
                    <div>
                        {QuizView}
                    </div>
                    }
                </div>
                :
                <div style={Wrapper3} className="card-3">
                    <div style={Title}><b>{this.props.quizName}</b></div>
                </div>
                }
            </div>
        );

        const tag =
            this.state.tagArray.map(data => (
                <span><a onClick={() => this.tagClick(data)}>{'#'+data}</a>&nbsp;&nbsp;</span>
                )
            )

        return (
            <div>
                {deleteMode ? 
                    deleteView 
                    :
                    <Link to={ this.state.bool ? link_save : link_read }>
                        {QuizView}
                    </Link>
                }
                <div style={Wrapper4} className='card-3'>
                    <div style={Label}>
                        {tag}
                    </div>
                </div>
            </div>
        );
    }
}

Quiz.propTypes = {
    deleteMode: PropTypes.bool,
    deleteFunction: PropTypes.func,
    tagC: PropTypes.func
};
 
Quiz.defaultProps = {
    deleteMode:false,
    deleteFunction: (key) => { console.error("deleteFunction function not defined"); },
    tagC: (data) => { console.error("tagC function not defined"); }
};

export default Quiz;