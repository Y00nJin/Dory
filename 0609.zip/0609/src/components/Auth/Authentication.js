import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import PropTypes from 'prop-types';


const Title = {
    fontSize: '1.5rem',
    fontWeight: '500',
    color: '#ef5d62',
    marginBottom: '1rem',
    marginLeft:'2rem',
    marginTop:'1rem',
    background: 'white'
}

const Wrapper = {
    marginTop: '1rem'
}

const Wrapper2 = {
    marginTop: '1rem',
    height: '2rem'
}

const Label = {
    fontSize: '1rem',
    color: 'gray',
    marginBottom: '0.25rem'
}

const Label2 = {
    fontSize: '1rem',
    color: 'red',
    marginBottom: '0.25rem'
}

const ButtonStyle = {
    marginTop: '1rem',
    paddingTop: '0.6rem',
    paddingBottom: '0.5rem',
    background: 'white',
    color: '#ef5d62',
    textAlign: 'center',
    fontSize: '1.25rem',
    fontWeight: '500',
    cursor: 'pointer',
    userSelect: 'none',
    transition: '.2s all',
    width: '100%',
    borderRadius:'5px'
}

const ButtonStyle2 = {
    marginTop: '1rem',
    background: 'white',
    color: 'gray',
    textAlign: 'center',
    fontSize: '1rem',
    fontWeight: '500',
    cursor: 'pointer',
    userSelect: 'none',
    width: '16%',
    paddingTop: '0.3rem',
    paddingBottom: '0.3rem',
    borderRadius:'5px'
}

const linkDiv = {
    marginTop: '1rem',
    textAlign: 'right'
}

const linkStyle = {
    color: 'gray'
}

const Positioner = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)'
}

// 너비, 그림자 설정
const ShadowedBox = {
    background: 'white',
    marginTop: '1rem'
}

// 로고
const LogoWrapper = {
    background: '#ef5d62',
    height: '4rem',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center'
}

const Logo = {
    color: 'white',
    fontFamily: 'Rajdhani',
    fontSize: '2rem',
    letterSpacing: '5px',
    textDecoration: 'none'
}

// children 이 들어가는 곳
const Contents = {
    background: 'white',
    padding: '2rem',
    height: 'auto'
}

class Authentication extends Component {

    constructor(props) {
        super(props);

        this.state = {
            username:"",
            password:"",
            cpassword:"",
            pwcheck:""
        }

        this.handleChange = this.handleChange.bind(this);
        this.handleKeyPress = this.handleKeyPress.bind(this);
        this.handleRegister = this.handleRegister.bind(this);
        this.handleLogin = this.handleLogin.bind(this);
    }
    
   
      handleChange(e){
          let nextState = {};
          nextState[e.target.name] = e.target.value;
          this.setState(nextState);
      }

      handleKeyPress(e){
        if(e.charCode==13) {
            if(this.props.mode) {
                this.handleLogin();
            } else {
                this.handleRegister();
            }
        }
    }
   
      handleRegister(){
          let id = this.state.username;
          let pw = this.state.password;
          let pw2 = this.state.cpassword;

          if(pw!=pw2){
            this.setState({
                cpassword: '',
                pwcheck: 'Passwords do not match'
            });
            return;
          }
   
          this.props.onRegister(id, pw).then(
              (result) => {
                  if(!result) {
                      this.setState({
                          username: '',
                          password: '',
                          cpassword: '',
                          pwcheck:''
                      });
                  }
              }
          );
      }

      handleLogin(){
        let id = this.state.username;
        let pw = this.state.password;
 
        this.props.onLogin(id, pw).then(
            (success) => {
                if(!success) {
                    this.setState({
                        password: ''
                    });
                }
            }
        );
    }


    render() {
        const loginView = (
            <div>
                <div style={Wrapper}>
                    <div style={Label}>E-mail</div>
                    <input name="username" placeholder="Email" type="email"
                    onChange={this.handleChange}
                    value={this.state.username}/>
                </div>
                <div style={Wrapper}>
                    <div style={Label}>Password</div>
                    <input name="password" placeholder="Password" type="password"
                    onChange={this.handleChange}
                    value={this.state.password}
                    onKeyPress={this.handleKeyPress}/>
                </div>
                <button style={ButtonStyle} onClick={this.handleLogin}>SignIN</button>
                <div style={linkDiv}><Link to='/auth/register' style={linkStyle}>SignUP</Link></div>
            </div>
        );
 
        const registerView = (
            <div>
                <div style={Wrapper}>
                    <div style={Label}>E-mail</div>
                    <input name="username" placeholder="Email"
                    onChange={this.handleChange}
                    value={this.state.username}/>
                </div>
                <div style={Wrapper}>
                    <div style={Label}>Password</div>
                    <input name="password" placeholder="Password" type="password"
                    onChange={this.handleChange}
                    value={this.state.password}/>
                </div>
                <div style={Wrapper}>
                    <div style={Label}>Check Password</div>
                    <input name="cpassword" placeholder="Check Password" type="password"
                    onChange={this.handleChange}
                    value={this.state.cpassword}
                    onKeyPress={this.handleKeyPress}/>
                </div>
                <div style={Wrapper2}>
                    <div style={Label2} name="pwcheck">{this.state.pwcheck}</div>
                </div>
                <button style={ButtonStyle} onClick={this.handleRegister}>SignUP</button>
                <div style={linkDiv}><Link to='/auth/login' style={linkStyle}>SignIN</Link>
                </div>
            </div>
        );
        return (
            <div style={Positioner}>
                <div style={ShadowedBox} className="ShadowedBox card-1">
                   <div style={LogoWrapper}>
                        <div style={Logo}>HYJ</div>
                    </div>

                    <div style={Title}><b>{this.props.mode ? "LOGIN" : "REGISTER"}</b></div>
                    <div style={Contents}>
                        {this.props.mode ? loginView : registerView }
                    </div>
                </div>
            </div>
        );
    }
}

Authentication.propTypes = {
    mode: PropTypes.bool,
    onRegister: PropTypes.func,
    onLogin: PropTypes.func
};
 
Authentication.defaultProps = {
    mode: true,
    onRegister: (id, pw) => { console.error("register function is not defined"); },
    onLogin: (id, pw) => { console.error("login function not defined"); }
};


export default Authentication;