import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import PropTypes from 'prop-types';
import ReadOption from './ReadOption';
import axios from 'axios';
import update from 'react-addons-update';
import { decorate, observable, action } from 'mobx';
import {observer} from "mobx-react"

// 너비, 그림자 설정
const ShadowedBox = {
    background: 'white'
}

// 로고
const LogoWrapper = {
    background: '#ef5d62',
    height: '0.3rem',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center'
}

const Logo = {
    color: '#ef5d62',
    fontFamily: 'Rajdhani',
    fontSize: '1rem',
    textDecoration: 'none'
}

// children 이 들어가는 곳
const Contents = {
    background: 'white',
    padding: '2rem',
    height: 'auto'
}

class ReadQuiz extends Component {

    constructor(props) {
        super(props);
        
        this.dbNum = null;
        this.number = this.props.num;
        this.quiztitle = '';
        this.value = 'select';
        this.quizoption = [];
        this.option = [];


        this.optionCheck = this.optionCheck.bind(this);
        this.getQuizList = this.getQuizList.bind(this);
    }
    
    componentDidMount(){
        this.getQuizList();
    }
    
    getQuizList() {
        const quizNum = this.props.content;
        this.dbNum = quizNum;
        axios.post('/api/board/quiztest', {quizNum})
		.then((response) => {
            this.quiztitle= response.data.quiz[0].quizname;
            this.quizoption= response.data.quiz[0].optionlist.split(',');
            this.value = response.data.quiz[0].tag;
            this.answer = response.data.quiz[0].answer.split('');
            this.score = response.data.quiz[0].score;
            
            for(var i=0; i<this.quizoption.length; i++){
                this.option = this.option.concat({
                    num: i,
                    content: this.quizoption[i],
                    check: false
                    })
            }
		})
		.catch((err)=>{
			console.log('Error fetching packageClick',err);
        });
    }

    componentDidUpdate(){
        const { onSubmit } = this.props;
        onSubmit(this.dbNum, this.number, this.option);
    }

    optionCheck(num, select) {
        this.option = update(
            this.option,
            {
                [num] : {
                    check: {$set: select}
                }
            }
        )
    }


    render() {
        const quizContentView = (
            <div>
                <div>
                    <div name="quiztitle" style={{fontSize:'20px', width:'70%', color:'black'}}
                    className="optionStyle">{this.quiztitle}</div>
                </div>
            </div>
        );

        const optionList = this.option.map(
            ({num, content, check}) => (
              <ReadOption
                num={num}
                content={content}
                check={check}
                key={num}
                optionCheck={this.optionCheck}
              />
            )
          );

        return (
            <div>
                <div style={ShadowedBox} className="ShadowedBox card-3">
                   <div>
                    </div>
                    <div style={Contents}>
                        { quizContentView }
                        { optionList }
                    </div>
                </div>
            </div>
        );
    }
}

ReadQuiz.propTypes = {
    onSubmit: PropTypes.func
};
 
ReadQuiz.defaultProps = {
    onSubmit: (dbNum, number, option) => { console.error("onSubmit function not defined"); }
};


decorate(ReadQuiz, {
    dbNum: observable,
    option: observable,
    quizoption: observable,
    getQuizList: action,
    optionCheck: action
  })

export default observer(ReadQuiz);