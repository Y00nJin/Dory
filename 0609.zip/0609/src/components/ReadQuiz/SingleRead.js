import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import PropTypes from 'prop-types';
import ReadOption from './ReadOption';
import axios from 'axios';
import update from 'react-addons-update';
import { decorate, observable, action } from 'mobx';
import {observer} from "mobx-react"

// 너비, 그림자 설정
const ShadowedBox = {
    background: 'white'
}

// children 이 들어가는 곳
const Contents = {
    background: 'white',
    padding: '2rem',
    height: 'auto'
}

const Positioner = {
    position: 'absolute',
    left: '50%',
    marginTop: '4rem',
    marginBottom: '4rem',
    transform: 'translate(-50%, 0)'
}

class SingleRead extends Component {

    constructor(props) {
        super(props);
        
        this.state = {
            loginData: {}
        }
        this.dbNum = null;
        this.number = this.props.num;
        this.quiztitle = '';
        this.value = 'select';
        this.quizoption = [];
        this.option = [];
        this.answer = '';
        this.upload = '';
        this.id = '';
        this.finalScore = 0;
        this.totalScore = 0;


        this.optionCheck = this.optionCheck.bind(this);
        this.getQuizList = this.getQuizList.bind(this);
        this.list = this.list.bind(this);
        this.handleInsert = this.handleInsert.bind(this);
    }
    
    componentDidMount(){
        this.getQuizList();
    }
    
    getQuizList() {
        const quizNum = this.props.match.params.num;
        this.id = this.props.match.params.id;
        this.dbNum = this.props.match.params.num;
        axios.post('/api/board/quiztest', {quizNum})
		.then((response) => {
            this.quiztitle= response.data.quiz[0].quizname;
            this.quizoption= response.data.quiz[0].optionlist.split(',');
            this.value = response.data.quiz[0].tag;
            
            for(var i=0; i<this.quizoption.length; i++){
                this.option = this.option.concat({
                    num: i,
                    content: this.quizoption[i],
                    check: false
                    })
            }
		})
		.catch((err)=>{
			console.log('Error fetching packageClick',err);
        });
    }


    optionCheck(num, select) {
        this.option = update(
            this.option,
            {
                [num] : {
                    check: {$set: select}
                }
            }
        )
    }

    list() {
        let bool = false;
        this.props.history.push('/quiz/packageList/'+bool);
    }

    handleInsert(){
        const email = this.id;
        this.answer = '';

        for(var j=0; j<this.option.length; j++){ // 답안 번호
            if(this.option[j].check){
                this.answer += j.toString();
            }

        }

        const dbnum = this.dbNum;
        const answer = this.answer;
        axios.post('/api/board/selectQuiz', {dbnum})
        .then((response) => {
            console.log(response);
            const dbAnswer = response.data.quiz[0].answer;
            const score = response.data.quiz[0].score;
            var correct = 'false';

            this.finalScore = score;

            if(dbAnswer===answer){
                this.totalScore += score;
                correct = 'true';
            }

            axios.post('/api/board/singleresultInsert', {dbnum, email, answer, correct})
            .then((response) => {
            })
            .catch((err)=>{
                console.log('Error fetching resultInsert',err);
            });

        })
        .catch((err)=>{
            console.log('Error fetching selectQuiz',err);
        });
        //this.componentChange = !this.componentChange;
        Materialize.toast('Success!', 2000);
        this.props.history.push('/quiz/packageList/false');
    }

    render() {
        const quizContentView = (
            <div>
                <div>
                    <div name="quiztitle" style={{fontSize:'25px', width:'70%', color:'black'}}
                    className="optionStyle">{this.quiztitle}</div>
                </div>
            </div>
        );

        const optionList = this.option.map(
            ({num, content, check}) => (
              <ReadOption
                num={num}
                content={content}
                check={check}
                key={num}
                optionCheck={this.optionCheck}
              />
            )
          );

        return (
            <div style={Positioner}>
                <div style={ShadowedBox} className="ShadowedBox card-3">
                   <div>
                    </div>
                    <div style={Contents}>
                        { quizContentView }
                        { optionList }
                    </div>
                </div>
                <div style={{textAlign: 'right'}}>
                    <button className="singlebutton btn-1" onClick={this.list}>LIST</button>
                    <button className="singlebutton2 btn-1" onClick={this.handleInsert}>SAVE</button>
                </div>
            </div>
        );
    }
}

decorate(SingleRead, {
    dbNum: observable,
    option: observable,
    quizoption: observable,
    answer: observable,
    id: observable,
    finalScore: observable,
    totalScore: observable,
    getQuizList: action,
    optionCheck: action
  })

export default observer(SingleRead);