import React from 'react';
import { Link } from 'react-router-dom';
import PropTypes from 'prop-types';

class Menu extends React.Component {

    constructor(props) {
        super(props);
    }

    render() {

        const InsertButton = (
            <li>
                <a onClick={this.props.onInsert}>
                    <i className="material-icons" style={{color:'white', fontSize:'40px', right:'20px',bottom:'10px', position:'fixed'}}>create</i>
                </a>
            </li>
        );
        const SearchButton = (
            <li>
                <Link to="/">
                    <i className="material-icons" style={{color:'white'}}>vpn_key</i>
                </Link>
            </li>
        );

        return (
            <div className="hihi">
                    <div className="header-wrap hi">
                        <ul>
                            { InsertButton }
                        </ul>
                    </div>
            </div>
        );
    }
}

Menu.propTypes = {
    onInsert: PropTypes.func
};
 
Menu.defaultProps = {
    onInsert: () => { console.error("Insert function not defined");}
};

export default Menu;
