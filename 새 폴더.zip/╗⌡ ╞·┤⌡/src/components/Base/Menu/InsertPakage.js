import React from 'react';
import { Link } from 'react-router-dom';
import PropTypes from 'prop-types';

class InsertPakage extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            Pname:"",
            content:"",
            loginData: {}
        }

        this.handleChange = this.handleChange.bind(this);
        this.handlePackageInsert = this.handlePackageInsert.bind(this);
        this.getSession = this.getSession.bind(this);

    }

    componentDidMount(){
        this.getSession();
    }

    handleChange(e){
        let nextState = {};
        nextState[e.target.name] = e.target.value;
        this.setState(nextState);
    }

    handlePackageInsert(){
        let pn = this.state.Pname;
        let pc = this.state.content;
        let loginData = this.state.loginData.username;

        console.log(loginData);

        this.props.onPackageInsert(pn, pc, loginData).then(
            (success) => {
                if(!success) {
                    this.setState({
                        Pname: '',
                        content: ''
                    });
                }
            }
        );
    }

    getSession() {
        function getCookie(name) {
            var value = "; " + document.cookie; 
            var parts = value.split("; " + name + "="); 
            if (parts.length == 2) return parts.pop().split(";").shift();
        }

        let loginData = getCookie('key');
        if(typeof loginData === "undefined") return;
        loginData = JSON.parse(atob(loginData));
        if(!loginData.isLoggedIn) return;

        console.log(loginData);

        this.setState({loginData: loginData});
    }

    render() {

        const Insert = (
            <div>
                <div className="packageInsert1">
                    <div className="packagefont"><b>PACKAGE</b></div>
                    <input type="text" name="Pname" placeholder="PACKAGE" className="packageInput"
                    onChange={this.handleChange}
                    value={this.state.Pname}/>
                </div>
                <div className="packageInsert1">
                    <div className="packagefont"><b>CONTENT</b></div>
                    <textarea name="content" placeholder="CONTENT" className="packageInput2"
                    onChange={this.handleChange}
                    value={this.state.content}/>
                </div>
                <button className="packageButton" onClick={this.handlePackageInsert}>
                    INSERT
                </button>
            </div>
        );

        return (
            <div className="packageInsert">
                    { Insert }
            </div>
        );
    }
}

InsertPakage.propTypes = {
    onPackageInsert: PropTypes.func
};
 
InsertPakage.defaultProps = {
    onPackageInsert: (pn, pc, loginData) => { console.error("PackageInsert function not defined"); }
};

export default InsertPakage;
