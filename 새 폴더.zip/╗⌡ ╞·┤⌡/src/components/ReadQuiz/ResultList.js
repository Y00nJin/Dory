import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import PropTypes from 'prop-types';
import ResultQuiz from './ResultQuiz';
import axios from 'axios';
import update from 'react-addons-update';
import { connect } from 'react-redux';
import { decorate, observable, action } from 'mobx';
import {observer} from "mobx-react"


const Wrapper = {
    marginTop: '1rem'
}


const Positioner = {
    position: 'absolute',
    left: '50%',
    marginTop: '4rem',
    marginBottom: '4rem',
    transform: 'translate(-50%, 0)'
}

// 너비, 그림자 설정
const ShadowedBox = {
    width: '600px',
    marginTop: '1rem'
}

// 로고
const LogoWrapper = {
    background: 'grey',
    border:'4px solid grey',
    height: '1rem',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center'
}

// children 이 들어가는 곳
const Contents = {
    background: 'white',
    padding: '2rem',
    height: 'auto'
}

const Contents2 = {
    background: 'white',
    height: 'auto'
}

const linkDiv = {
    marginTop: '1rem',
    textAlign: 'right'
}

const linkStyle = {
    color: 'gray'
}

class ResultList extends Component {

    constructor(props) {
        super(props);

        this.num = 0;
        this.packagetitle = '';
        this.packagecontent = '';
        this.packagenum = 0;
        this.quizlist = {};
        this.resultList = {};
        this.quiz = [];
        this.result = [];


        this.getQuizList = this.getQuizList.bind(this);

    }
    
   
    componentDidMount() {
        this.getQuizList();
    }

    getQuizList() {
        console.log(this.props.pnum);
        console.log(this.props.rnum);
        axios.get('/api/board/packageClick',{
            params: {
                num: this.props.pnum
            }
        })
		.then((response) => {
            this.packagetitle = response.data.package[0].title;
            this.packagecontent = response.data.package[0].content;
            this.packagenum = response.data.package[0].num;

            const list = response.data.package[0].quizlist.substr(0, response.data.package[0].quizlist.length-1);
            this.quizlist = list.split(',');

            const list2 = this.props.rnum.substr(0, this.props.rnum.length-1);
            this.resultList = list2.split(',');
            
            const start = parseInt(this.resultList[0]);
            const end = parseInt(this.resultList[this.resultList.length-1]);

            for(var k=0; k<this.quizlist.length; k++){
                axios.post('/api/board/selectResultNumber', {start, end, quiznum : this.quizlist[k]})
                .then((response) => {
                    this.result[this.num] = response.data.result[0].num;
                    console.log(this.quizlist[this.num]+':'+this.result[this.num]);
                    this.quiz = this.quiz.concat({
                        num: this.num,
                        content: this.quizlist[this.num],
                        result: this.result[this.num]
                        });
                        this.num++;
                })
                .catch((err)=>{
                    console.log('Error fetching selectResultNumber',err);
                });
            }
		})
		.catch((err)=>{
			console.log('Error fetching packageClick',err);
        });
    }


    render() {

        const quizView = (
            <div>
                <div style={Wrapper}>
                    <div name="packagetitle" style={{fontSize:'30px', color:'black'}}>
                        {this.packagetitle}
                    </div>
                </div>
                <div style={Wrapper}>
                    <div name="packagecontent" style={{fontSize:'15px', color:'gray'}}>
                        {this.packagecontent}
                    </div>
                </div>
            </div>
        );

        const quizcontentList = this.quiz.map(
            ({num, content, result}) => (
              <ResultQuiz
                num={num}
                content={content}
                result={result}
                key={num}
                onSubmit={this.handleSubmit}
              />
            )
          );


        return (
            <div>
                <div style={Positioner}>
                        <div style={linkDiv}><Link to='/quiz/packageList' style={linkStyle}>다른 패키지 풀기</Link>
                        </div>
                        <div style={ShadowedBox} className="card-3">
                            <div style={LogoWrapper}>
                            </div>
                            <div style={Contents}>
                                { quizView }
                            </div>
                        </div>
                        <div style={Contents2}>
                            { quizcontentList }
                        </div>
                    </div>
            </div>
        );
    }
}

decorate(ResultList, {
    num : observable,
    packagetitle : observable,
    packagecontent : observable,
    packagenum : observable,
    quizlist : observable,
    resultList : observable,
    result : observable,
    quiz : observable
  })

export default observer(ResultList);