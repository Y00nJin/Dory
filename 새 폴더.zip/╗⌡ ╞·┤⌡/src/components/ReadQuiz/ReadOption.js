import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import PropTypes from 'prop-types';
import { decorate, observable, action } from 'mobx';
import {observer} from "mobx-react"

const Wrapper = {
    marginTop: '1rem'
}


const ButtonStyle = {
    cursor: 'pointer',
    display: 'inline'
}


class ReadOption extends Component {

    constructor(props) {
        super(props);

        this.num = this.props.num;
        this.quizoption = this.props.content;
        this.select = false;
        this.check = this.props.check;

        this.handleAnswer = this.handleAnswer.bind(this);
        this.handleChange = this.handleChange.bind(this);
    }

    componentDidUpdate() {
        const { optionCheck } = this.props;
        optionCheck(this.num, this.check);
    }

    handleChange(e){
        this[e.target.name] = e.target.value;
    }

    handleAnswer(){
        this.check = !this.check;
    }

    render() {
        const optionView = (
            <div>
                <div style={Wrapper}>
                    <label onClick={this.handleAnswer} style={ButtonStyle} onChange={this.handleChange}>
                        { this.check ? 
                        <i className="material-icons optionStyle" style={{color:'red'}}>check_circle_outline</i>
                        :
                        <i className="material-icons optionStyle" style={{color:'gray'}}>radio_button_unchecked</i>
                        }
                    </label>
                    &nbsp;&nbsp;
                    <div id="option1" style={{width:'80%', fontSize:'17px', color:'gray'}} className="optionStyle">
                        {this.quizoption}
                    </div>
                    &nbsp;&nbsp;&nbsp;
                </div>
            </div>
        );

        return (
            <div>{ optionView }</div>
        );
    }
}

ReadOption.propTypes = {
    optionCheck: PropTypes.func
};
 
ReadOption.defaultProps = {
    optionCheck: (number, check) => { console.error("optionCheck function not defined"); }
};

decorate(ReadOption, {
    num: observable,
    quizoption: observable,
    check: observable,
    handleAnswer: action,
    handleChange: action
  })

export default observer(ReadOption);
