import React from 'react';
import { Link } from 'react-router-dom';
import PropTypes from 'prop-types';
import Package from './Package';
import 'whatwg-fetch';
import { connect } from 'react-redux';
import { getStatusRequest } from 'actions/authentication';
import axios from 'axios';



class PackageList extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            data: '',
            packageData:[],
            loginData: {}
        };

        this.getPacakageList = this.getPacakageList.bind(this);
        this.getSession = this.getSession.bind(this);

    }

    componentDidMount() {
        this.getPacakageList();
        this.getSession();
        //this.timer = setInterval(() => this.getPacakageList(), 1000);
    }

    componentWillUnmount() {
        this.timer = null;
      }  

    getPacakageList() {
        fetch('/api/board/package')
		.then((response) => response.json())
		.then((response) => {
			this.setState({packageData: response.data});
		})
		.catch((err)=>{
			console.log('Error fetching package',err);
        });
        
    }

    getSession() {
        function getCookie(name) {
            var value = "; " + document.cookie; 
            var parts = value.split("; " + name + "="); 
            if (parts.length == 2) return parts.pop().split(";").shift();
        }

        let loginData = getCookie('key');
        if(typeof loginData === "undefined") return;
        loginData = JSON.parse(atob(loginData));
        if(!loginData.isLoggedIn) return;

        console.log(loginData);

        this.setState({loginData: loginData});
    }

    render() {
        const View = (
            this.state.packageData.map((data, i) => {
                return (<Package num={data.num}
                                 packageName={data.title}
                                 content={data.content}
                                 username={this.state.loginData.username}
                                 key={i}/>);
                }
            )
        );
        return (
            <div style={{marginTop:'30px'}}>
                {View}
            </div>
        );
    }
}

PackageList.propTypes = {
    num: PropTypes.num
};
 
PackageList.defaultProps = {
    num: 0
};

const mapStateToProps = (state) => {
    return {
        status: state.authentication.status
    };
};
 
const mapDispatchToProps = (dispatch) => {
    return {
        getStatusRequest: () => {
            return dispatch(getStatusRequest());
        }
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(PackageList);