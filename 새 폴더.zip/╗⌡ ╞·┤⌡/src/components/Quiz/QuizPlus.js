import React, { Component } from 'react';
import axios from 'axios';
import update from 'react-addons-update';
import PropTypes from 'prop-types';


const Wrapper = {
    marginTop: '1rem'
}


const Positioner = {
    position: 'absolute',
    left: '50%',
    marginTop: '4rem',
    marginBottom: '4rem',
    transform: 'translate(-50%, 0)'
}

const Positioner2 = {
    position:'fixed',
    top:'50%',
    right:'20%',
    cursor: 'pointer'
}

// 너비, 그림자 설정
const ShadowedBox = {
    width: '300px',
    height: '800px',
    position:'fixed',
    top:'10%',
    left:'1rem'
}

// 로고
const LogoWrapper = {
    background: '#ff4545',
    border:'4px solid #ff4545',
    height: '3rem',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center'
}

const Logo = {
    color: '#ff4545',
    fontFamily: 'Rajdhani',
    fontSize: '3rem',
    letterSpacing: '7px',
    textDecoration: 'none'
}

// children 이 들어가는 곳
const Contents = {
    background: 'white',
    padding: '2rem',
    height: 'auto'
}

const Contents2 = {
    background: 'white',
    height: 'auto'
}

class QuizPlus extends Component {

    constructor(props) {
        super(props);


        this.state = {
            quiz : []
        };

        this.getQuizList = this.getQuizList.bind(this);
        this.click = this.click.bind(this);
        this.handleInsert = this.handleInsert.bind(this);

    }
    
   
    componentDidMount() {
        this.getQuizList();
    }
    
    getQuizList() {
        axios('/api/board/quiz')
		.then((response) => {
            var count = 0;
            for(var i=0; i<response.data.data.length; i++){
                this.setState({
                    quiz : this.state.quiz.concat({
                        num: response.data.data[i].num,
                        quizname: response.data.data[i].quizname,
                        count: count++,
                        select: false
                        })
                });
            }
		})
		.catch((err)=>{
			console.log('Error fetching package',err);
        });
        
    }

    click(key){
        this.setState({
            quiz: update(
                this.state.quiz,
                {
                    [key] : {
                        select: {$set: !this.state.quiz[key].select}
                    }
                }
            )
        });
    }

    handleInsert() {
        const { onInsert } = this.props;

        let quizNumber = '';
        for(var i=0; i<this.state.quiz.length; i++){
            if(this.state.quiz[i].select==true){
                quizNumber += this.state.quiz[i].num + ',';
            }
        }

        quizNumber = quizNumber.substr(0, quizNumber.length-1);

        onInsert(quizNumber);
    }

    render() {

        const View = this.state.quiz.map(
            data => (
                <Info num={data.num}
                    quizname={data.quizname}
                    number={data.count}
                    key={data.count}
                    select={data.select}
                    onhandleClick={this.click}
                />
            )
          );

        return (
            <div className="scroll" style={ShadowedBox}>
                <button onClick={this.handleInsert}>추가하기</button>
                {View}
            </div>
        );
    }
}

class Info extends React.Component {
    constructor(props) {
        super(props);


        this.state = {
            key : this.props.number,
            num : this.props.num,
            quizname : this.props.quizname,
            select : this.props.select
        };

        this.handleClick = this.handleClick.bind(this);
    }

    handleClick(){
        const { onhandleClick } = this.props;
        const { key } = this.state;
        onhandleClick(key);
        this.setState({
            select : !this.state.select
        });
    }

    render() {
        const { num, quizname, select } = this.state;
        return(
            <div>
                {
                select ?
                <ol style={{color:'red'}} onClick={this.handleClick}>{num} {quizname}</ol>
                :
                <ol style={{color:'black'}} onClick={this.handleClick}>{num} {quizname}</ol>
                }
            </div>
        )
    }
}

Info.propTypes = {
    onhandleClick: PropTypes.func
};
 
Info.defaultProps = {
    onhandleClick: (number) => { console.error("handleClick function not defined"); }
};

QuizPlus.propTypes = {
    onInsert: PropTypes.func
}

QuizPlus.defaultProps = {
    onInsert : (quizNumber) => { console.error("onInsert function not defined"); }
}

export default QuizPlus;
