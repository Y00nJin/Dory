import React from 'react';
import { Link } from 'react-router-dom';
import { decorate, observable, action } from 'mobx';
import {observer} from "mobx-react"
import axios from 'axios';


const Title = {
    fontSize: '1.5rem',
    fontWeight: '500',
    color: '#ef5d62',
    paddingTop:'20px',
    paddingBottom: '30px',
    background: 'white',
    textAlign: 'center'
}

const Wrapper = {
    marginTop: '1rem',
    width: '220px',
    height: '220px',
    background: 'white'
}

const Label = {
    fontSize: '1rem',
    color: 'gray',
    marginBottom: '0.25rem',
    textAlign: 'center'
}

class Package extends React.Component {

    constructor(props) {
        super(props);

        this.session = this.props.username;
        this.email = '';
        this.bool = false;
    }

    componentDidMount() {
        axios.get('/api/board/packageClick',{
            params: {
                num: this.props.num
            }
        })
		.then((response) => {
            this.email = response.data.package[0].id
            if(this.email==this.session){
                this.bool = true;
            }
		})
		.catch((err)=>{
			console.log('Error fetching packageClick',err);
        });
    }

    render() {
        const { num } = this.props;
        let link_read = '/quiz/read/' + num ;
        let link_save = '/quiz/quizList/' + num ;
            const packageView = (
                <div>
                    <div style={Wrapper} className="card-1">
                        <div style={Title}><b>{this.props.packageName}</b></div>
                        <div style={Label}>{this.props.content}</div>
                    </div>
                </div>
            );

        return (
            <div className="grid4 col">
                <Link to={ this.bool ? link_save : link_read }>
                    {packageView}
                </Link>
            </div>
        );
    }
}

decorate(Package, {
    email: observable,
    session: observable,
    bool: observable
  })

export default observer(Package);