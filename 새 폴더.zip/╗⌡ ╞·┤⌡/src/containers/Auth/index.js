export { default as Login } from './Login';
export { default as Register } from './Register';

// 내보낼 컴포넌트 정리
//import Login from './Login';
//import Register from './Register';

//export { Login, Register };
