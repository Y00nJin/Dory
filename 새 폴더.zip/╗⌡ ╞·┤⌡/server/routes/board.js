import express from "express";
import conn from "../db/mysql.js";

const router = express.Router();

router.get('/package', (req, res) =>{
	conn.query("SELECT * FROM package ORDER BY num DESC", (err, results) => {
		if(err) {
			return res.send(err);
		}else {
			return res.json({
				data: results
			})
		}
	});
});

router.post("/packageInsert", (req, res) => {
	const pname = req.body.pname;
	const content = req.body.content;
	const loginId = req.body.loginData;
	console.log(loginId);
	let sql = "INSERT INTO package (title, content, id) VALUES(?,?,?)";
		  let post = [pname, content, loginId];
		  conn.query(sql, post, (err, results, fields) => {
			if (err) {
			  console.log(err);
			  return res.status(400).json({
				error: "db error"
			 });
			} else {
			  return res.status(200).json({
				success: true,
				error: null,
				num : results.insertId
			  });
			}
		  });
	});
	
	router.get("/packageClick", (req, res) => {
		const package_num = req.query.num;
		console.log(req.query.num);
		let sql = "SELECT * FROM package WHERE num=?";
		
    let post = [package_num];

    conn.query(sql, post, (err, results) => {
			console.log(results);
      if (err) { 
				throw err
			}
      else {
				return res.status(200).json({
					package: results
				})
			}  
    });
	})
	
	router.post("/packageUpdate", (req, res) => {
		const packagenum = req.body.packagenum;
		const quizlist = req.body.quizlist;
		console.log(packagenum);
		console.log(quizlist);
		let sql = "UPDATE package SET quizlist = ? WHERE num = ?";
				let post = [quizlist, packagenum];
				conn.query(sql, post, (err, results, fields) => {
				if (err) {
					console.log(err);
					return res.status(400).json({
					error: "db error"
				 });
				} else {
					return res.status(200).json({
					success: true,
					error: null
					});
				}
				});
		});

	router.post("/quizInsert", (req, res) => {
		const quizname = req.body.title;
		const optionlist = req.body.option;
		const tag = req.body.val;
		const answer = req.body.answer;
		const score = req.body.score;
		const bool = req.body.bool;

		if(bool==false){
			return res.status(200).json({
				num: null
			 });
		}

		let sql = "INSERT INTO quiz (quizname, optionlist, tag, answer, score) VALUES(?,?,?,?,?)";
				let post = [quizname, optionlist, tag, answer, score];
				conn.query(sql, post, (err, results, fields) => {
				if (err) {
					console.log(err);
					return res.status(400).json({
					error: "db error"
				 });
				} else {
					console.log(results.insertId);
					return res.status(200).json({
						num : results.insertId
					});
				}
				});
		});

	router.get('/quiz', (req, res) =>{
		conn.query("SELECT num, quizname FROM quiz", (err, results) => {
			if(err) {
				return res.send(err);
			}else {
				return res.json({
					data: results
				})
			}
		});
	});

	router.post("/selectQuiz", (req, res) => {
		const quizKey = req.body.dbnum;
		let sql = "SELECT * FROM quiz WHERE num = ?";
		let post = [quizKey];
		conn.query(sql, post, (err, results, fields) => {
			if (err) { 
				throw err
			} else {
				return res.status(200).json({
					quiz : results
				});
			}
			});
		});

		router.post('/quiztest', (req, res) =>{
			const quizKey = req.body.quizNum;

			let sql = "SELECT * FROM quiz WHERE num = ?";
			let post = [quizKey];
			conn.query(sql, post, (err, results) => {
				if(err) {
					return res.send(err);
				}else {
					return res.json({
						quiz: results
					})
				}
			});
		});

		router.post("/resultInsert", (req, res) => {
			const package_number = req.body.pknum;
			const quiz_number = req.body.dbnum;
			const email = req.body.email;
			const quiz_answer = req.body.answer;
			const correct = req.body.correct;

			let sql = "INSERT INTO result (package_number, quiz_number, email, quiz_answer, correct) VALUES(?,?,?,?,?)";
					let post = [package_number, quiz_number, email, quiz_answer, correct];
					conn.query(sql, post, (err, results, fields) => {
					if (err) {
						console.log(err);
						return res.status(400).json({
						error: "db error"
					 });
					} else {
						console.log(results.insertId);
						return res.status(200).json({
							num : results.insertId
						});
					}
					});
			});

			router.post("/resultGroupInsert", (req, res) => {
				const package_number = req.body.pknum;
				const email = req.body.email;
	
				let sql = "INSERT INTO result_group (package_number, email) VALUES(?,?)";
						let post = [package_number, email];
						conn.query(sql, post, (err, results, fields) => {
						if (err) {
							console.log(err);
							return res.status(400).json({
							error: "db error"
						 });
						} else {
							console.log(results.insertId);
							return res.status(200).json({
								num : results.insertId
							});
						}
					});
			});

			router.post("/resultGroupUpdate", (req, res) => {
				const num = req.body.resultNum;
				const list = req.body.uploadList;

				let sql = "UPDATE result_group SET result_number = ? WHERE num = ?";
						let post = [list, num];
						conn.query(sql, post, (err, results, fields) => {
						if (err) {
							console.log(err);
							return res.status(400).json({
							error: "db error"
						});
						} else {
							return res.status(200).json({
								num : results.insertId
							});
						}
						});
				});

			router.post("/selectResultGroup", (req, res) => {
				const rnum = req.body.rnum;
				let sql = "SELECT * FROM result_group WHERE num = ?";
				let post = [rnum];
				conn.query(sql, post, (err, results, fields) => {
					if (err) { 
						throw err
					} else {
						return res.status(200).json({
							result_group : results
						});
					}
					});
				});

			router.get("/selectEmailResultGroup", (req, res) => {
				const email = req.query.email;
				let sql = "SELECT * FROM result_group WHERE email = ?";
				let post = [email];
				conn.query(sql, post, (err, results, fields) => {
					if (err) { 
						throw err
					} else {
						return res.status(200).json({
							results
						});
					}
					});
				});

			router.post("/selectResult", (req, res) => {
				const rnum = req.body.resultNum;
				let sql = "SELECT * FROM result WHERE num = ?";
				let post = [rnum];
				conn.query(sql, post, (err, results, fields) => {
					if (err) { 
						throw err
					} else {
						return res.status(200).json({
							result : results
						});
					}
					});
				});

			router.post("/selectResultNumber", (req, res) => {
				const start = req.body.start;
				const end = req.body.end;
				const quiznum = req.body.quiznum;
				let sql = "SELECT num FROM result WHERE num >= ? and num <= ? and quiz_number = ?";
				let post = [start, end, quiznum];
				conn.query(sql, post, (err, results, fields) => {
					if (err) { 
						throw err
					} else {
						return res.status(200).json({
							result : results
						});
					}
					});
				});

export default router;
