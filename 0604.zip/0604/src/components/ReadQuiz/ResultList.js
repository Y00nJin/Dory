import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import PropTypes from 'prop-types';
import ResultQuiz from './ResultQuiz';
import axios from 'axios';
import update from 'react-addons-update';
import { connect } from 'react-redux';
import { decorate, observable, action } from 'mobx';
import {observer} from "mobx-react"


const Wrapper = {
    marginTop: '1rem'
}


const Positioner = {
    position: 'absolute',
    left: '50%',
    marginTop: '4rem',
    marginBottom: '4rem',
    transform: 'translate(-50%, 0)'
}

// 너비, 그림자 설정
const ShadowedBox = {
    width: '600px',
    marginTop: '1rem'
}

// 로고
const LogoWrapper = {
    background: 'grey',
    border:'4px solid grey',
    height: '1rem',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center'
}

// children 이 들어가는 곳
const Contents = {
    background: 'white',
    padding: '2rem',
    height: 'auto'
}

const Contents2 = {
    background: 'white',
    height: 'auto'
}

const linkDiv = {
    marginTop: '1rem',
    textAlign: 'right'
}

const linkStyle = {
    color: 'gray'
}

class ResultList extends Component {

    constructor(props) {
        super(props);

        this.num = 0;
        this.packagetitle = '';
        this.packagecontent = '';
        this.packagenum = 0;
        this.quizlist = {};
        this.quiz = [];
        this.id = this.props.id;
        this.pnum = this.props.pnum;

        this.getQuizList = this.getQuizList.bind(this);

    }
    
   
    componentDidMount() {
        this.getQuizList();
    }

    getQuizList() {
        let packagenum = this.props.pnum;
        let id = this.props.id;

        if(typeof(packagenum) == 'undefined' && typeof(id) == 'undefined'){
            packagenum = parseInt(this.props.match.params.num);
            id = this.props.match.params.id;
            this.id = this.props.match.params.id;
            this.pnum = parseInt(this.props.match.params.num);
            console.log(packagenum);
            console.log(id);
        }

        axios.get('/api/board/packageClick',{
            params: {
                num: packagenum
            }
        })
		.then((response) => {
            this.packagetitle = response.data.package[0].title;
            this.packagecontent = response.data.package[0].content;
            this.packagenum = response.data.package[0].num;

            const list = response.data.package[0].quizlist.substr(0, response.data.package[0].quizlist.length-1);
            this.quizlist = list.split(',');

            for(var k=0; k<this.quizlist.length; k++){
                    this.quiz = this.quiz.concat({
                        num: this.num++,
                        content: this.quizlist[k]
                    });
            }
		})
		.catch((err)=>{
			console.log('Error fetching packageClick',err);
        });
    }


    render() {

        const quizView = (
            <div>
                <div style={Wrapper}>
                    <div name="packagetitle" style={{fontSize:'30px', color:'black'}}>
                        {this.packagetitle}
                    </div>
                </div>
                <div style={Wrapper}>
                    <div name="packagecontent" style={{fontSize:'15px', color:'gray'}}>
                        {this.packagecontent}
                    </div>
                </div>
            </div>
        );

        const quizcontentList = this.quiz.map(
            data => (
              <ResultQuiz
                num={data.num}
                content={data.content}
                key={data.num}
                onSubmit={this.handleSubmit}
                packagenum={this.pnum}
                id={this.id}
              />
            )
          );


        return (
            <div>
                <div style={Positioner}>
                        <div style={linkDiv}><Link to='/quiz/packageList/true' style={linkStyle}>다른 패키지 풀기</Link>
                        </div>
                        <div style={ShadowedBox} className="card-3">
                            <div style={LogoWrapper}>
                            </div>
                            <div style={Contents}>
                                { quizView }
                            </div>
                        </div>
                        <div style={Contents2}>
                            { quizcontentList }
                        </div>
                    </div>
            </div>
        );
    }
}

decorate(ResultList, {
    num : observable,
    packagetitle : observable,
    packagecontent : observable,
    packagenum : observable,
    quizlist : observable,
    quiz : observable,
    id : observable,
    pnum : observable
  })

export default observer(ResultList);