import React from 'react';
import { Link } from 'react-router-dom';
import PropTypes from 'prop-types';

class Header extends React.Component {

    constructor(props) {
        super(props);

        // IMPLEMENT: CREATE A SEARCH STATUS

        this.state = {
            search: false
        };

       // this.toggleSearch = this.toggleSearch.bind(this);
    }

    /*toggleSearch() {
        this.setState({
            search: !this.state.search
        });
    }*/
    

    render() {

        const loginButton = (
            <li>
                <Link to="/auth/login">
                    <i className="material-icons">vpn_key</i>
                </Link>
            </li>
        );
        const logoutButton = (
            <li>
                <a onClick={this.props.onLogout}>
                    <i className="material-icons">lock_open</i>
                </a>
            </li>
        );

        let link = "/quiz/packageList/" + true ;

        return (
            <div>
                <nav>
                    <div className="nav-wrapper #ef5d62 card-1">
                        <ul>
                            { this.props.isLoggedIn ? 
                                <li><Link to={link}><i className="material-icons">question_answer</i></Link></li> 
                                : 
                                <li><Link to="/quiz/fail"><i className="material-icons">question_answer</i></Link></li> 
                            }
                        </ul>
                        <div className="brand-logo center"><Link to='/' style={{fontFamily: 'Rajdhani'}}>HANYOONJIN</Link></div>
                        <ul className="right">
                            { this.props.isLoggedIn ? logoutButton : loginButton }
                        </ul>
                    </div>
                </nav>

            </div>
        );
    }
}

Header.propTypes = {
    isLoggedIn: PropTypes.bool,
    onLogout: PropTypes.func
};
 
Header.defaultProps = {
    isLoggedIn: false,
    onLogout: () => { console.error("logout function not defined");}
};

export default Header;
