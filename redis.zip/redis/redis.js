﻿var http = require('http');
var url = require('url');
var fs = require('fs');
var io = require('socket.io')();
var redis = require('redis');
var client = redis.createClient(6379,'localhost',{no_ready_check:true});

var httpServer = http.createServer(function (request, response) {
    var path = url.parse(request.url).pathname; 

    if (path ==='/') {
        fs.readFile(__dirname + '/redis.html', 'utf8', function(err, data) {

            if (err) {
                response.writeHead(404);
                response.write("404 Error: Oop index.html file doesn't exist");
                response.end();
            }
            else {
                response.writeHead(200, {'Content-Type' : 'text/html'});
                response.write(data, 'utf8');
                response.end();
            }
        });   
    }
});

httpServer.listen(8080, function() {
    console.log("http Server has been started on port 8080");
});

io.listen(httpServer);

io.on('connection', function(socket){

    socket.on('save', function (key, value) {
        console.log(value);
        client.set(key, value, function (err, reply) {
            console.log(reply);
        });
    });
});

