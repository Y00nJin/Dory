import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import PropTypes from 'prop-types';
import ReadQuiz from './ReadQuiz';
import axios from 'axios';
import update from 'react-addons-update';
import { connect } from 'react-redux';
import { decorate, observable, action } from 'mobx';
import {observer} from "mobx-react"
import ResultList from './ResultList';


const Wrapper = {
    marginTop: '1rem'
}


const Positioner = {
    position: 'absolute',
    left: '50%',
    marginTop: '4rem',
    marginBottom: '4rem',
    transform: 'translate(-50%, 0)'
}

const Positioner2 = {
    position: 'absolute',
    left: '50%',
    top: '30%',
    transform: 'translate(-50%, 0)'
}

// 너비, 그림자 설정
const ShadowedBox = {
    width: '600px',
    marginTop: '1rem'
}

// 로고
const LogoWrapper = {
    background: '#ff4545',
    border:'4px solid #ff4545',
    height: '1rem',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center'
}

const LogoWrapper2 = {
    background: '#ff4545',
    border:'4px solid #ff4545',
    height: '4rem',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center'
}

const Logo = {
    color: 'white',
    fontFamily: 'Rajdhani',
    fontSize: '2rem',
    letterSpacing: '7px',
    textDecoration: 'none'
}

// children 이 들어가는 곳
const Contents = {
    background: 'white',
    padding: '2rem',
    height: 'auto'
}

const Contents2 = {
    background: 'white',
    height: 'auto'
}

const linkDiv = {
    marginTop: '1rem',
    textAlign: 'right',
    color: 'gray',
    cursor: 'pointer'
}


const ButtonStyle = {
    marginTop: '2rem',
    marginLeft: '2rem',
    marginBottom: '2rem',
    paddingTop: '0.6rem',
    paddingBottom: '0.5rem',
    background: 'gray',
    color: 'white',
    textAlign: 'center',
    fontSize: '1.25rem',
    fontWeight: '500',
    cursor: 'pointer',
    userSelect: 'none',
    transition: '.2s all',
    width: '20%',
    borderRadius:'5px'
}

class ReadList extends Component {

    constructor(props) {
        super(props);

        this.packagetitle = '';
        this.packagecontent = '';
        this.packagenum = 0;
        this.quizlist = {};
        this.quiznum = 0;
        this.quiz = [];
        this.submitQuiz = [];
        this.finalScore = 0;
        this.totalScore = 0;
        this.componentChange = false;
        this.resultConfirm = true;
        this.uploadNum = null;
        this.uploadList = '';

        this.session = {};

        this.getQuizList = this.getQuizList.bind(this);
        this.handleSubmit = this.handleSubmit.bind(this);
        this.handleInsert = this.handleInsert.bind(this);
        this.linkFunction = this.linkFunction.bind(this);
        this.getSession = this.getSession.bind(this);
        this.confirm = this.confirm.bind(this);

    }
    
   
    componentDidMount() {
        this.getQuizList();
        this.getSession();
    }

    getQuizList() {
        axios.get('/api/board/packageClick',{
            params: {
                num: this.props.match.params.num
            }
        })
		.then((response) => {
            this.packagetitle = response.data.package[0].title;
            this.packagecontent = response.data.package[0].content;
            this.packagenum = response.data.package[0].num;

            const list = response.data.package[0].quizlist.substr(0, response.data.package[0].quizlist.length-1);
            this.quizlist = list.split(',');

            for(var i=0; i<this.quizlist.length; i++){
                this.quiz = this.quiz.concat({
                    num: i,
                    content: this.quizlist[i]
                    });

                this.submitQuiz = this.submitQuiz.concat({
                    dbnum: null,
                    option: null
                });
            }
		})
		.catch((err)=>{
			console.log('Error fetching packageClick',err);
        });
    }

    getSession() {
        function getCookie(name) {
            var value = "; " + document.cookie; 
            var parts = value.split("; " + name + "="); 
            if (parts.length == 2) return parts.pop().split(";").shift();
        }

        let loginData = getCookie('key');
        if(typeof loginData === "undefined") return;
        loginData = JSON.parse(atob(loginData));
        if(!loginData.isLoggedIn) return;

        console.log(loginData);

        this.session = loginData;
    }

    handleSubmit(dbNum, number, option){
        this.submitQuiz = update(
            this.submitQuiz,
            {
                [number] : {
                    dbnum: {$set: dbNum},
                    option: {$set: option}
                }
            }
        )
    }

    handleInsert(){
        const pknum = this.packagenum;
        const email = this.session._id;
        let resultNum = null;
        let uploadList = '';

        axios.post('/api/board/countUpdate', {pknum});

        for(var i=0; i<this.submitQuiz.length; i++){ // 퀴즈 번호
            this.answer = '';
            console.log(this.submitQuiz[i].option.length);
            for(var j=0; j<this.submitQuiz[i].option.length; j++){ // 답안 번호
                if(this.submitQuiz[i].option[j].check){
                    this.answer += j.toString();
                }

            }

            const dbnum = this.submitQuiz[i].dbnum;
            const answer = this.answer;
            
            axios.post('/api/board/selectQuiz', {dbnum})
                .then((response) => {
                    const dbAnswer = response.data.quiz[0].answer;
                    const score = response.data.quiz[0].score;
                    var correct = 'false';
                    var total_score = 0;

                    this.finalScore += score;

                    if(dbAnswer===answer){
                        this.totalScore += score;
                        total_score += score;
                        correct = 'true';
                    }

                    axios.post('/api/board/resultInsert', {pknum, dbnum, email, answer, correct, total_score})
                    .then((response) => {
                        this.uploadList = this.uploadList + response.data.num + ',';
                    })
                    .catch((err)=>{
                        console.log('Error fetching resultInsert',err);
                    });

                })
                .catch((err)=>{
                    console.log('Error fetching selectQuiz',err);
                });
        }
        this.componentChange = !this.componentChange;
    }

    linkFunction(){
        this.componentChange = !this.componentChange;
        this.totalScore = 0;
        this.finalScore = 0;
    }

    confirm(){
        this.resultConfirm = !this.resultConfirm;
    }

    render() {

        const quizView = (
            <div>
                <div style={Wrapper}>
                    <div name="packagetitle" style={{fontSize:'30px', color:'black'}}>
                        {this.packagetitle}
                    </div>
                </div>
                <div style={Wrapper}>
                    <div name="packagecontent" style={{fontSize:'15px', color:'gray'}}>
                        {this.packagecontent}
                    </div>
                </div>
            </div>
        );

        const resultView = (
            <div>
                {this.resultConfirm ?
                <div style={Positioner2}>
                    <div style={ShadowedBox} className="card-3">
                        <div style={LogoWrapper2}>
                            <div style={Logo}>
                                <b>SCORE</b>
                            </div>
                        </div>
                        <div style={Wrapper}>
                            <div style={{fontSize:'50px', textAlign:'center'}}>
                                <span style={{color:'red'}}><b>{this.totalScore}</b></span>
                                <span style={{color:'gray'}}> / {this.finalScore}</span>
                            </div>
                        </div>
                    </div>
                    <div style={linkDiv}>
                        <span onClick={this.confirm}><b>답 확인하기</b></span>
                        <span onClick={this.linkFunction}>  /  다시 응답 제출</span>
                    </div>
                </div>
                :    
                <ResultList pnum={this.packagenum} rnum={this.uploadList}/>
                }
            </div>
        );

        const quizcontentList = this.quiz.map(
            ({num, content}) => (
              <ReadQuiz
                num={num}
                content={content}
                key={num}
                onSubmit={this.handleSubmit}
              />
            )
          );


        return (
            <div>
                {this.componentChange ? 
                    <div> 
                        { resultView } 
                    </div>
                    :
                    <div style={Positioner}>
                        <div style={ShadowedBox} className="card-3">
                            <div style={LogoWrapper}>
                            </div>
                            <div style={Contents}>
                                { quizView }
                            </div>
                        </div>
                        <div style={Contents2}>
                            { quizcontentList }
                        </div>
                        <div style={Contents2} className="card-3">
                            <button style={ButtonStyle} onClick={this.handleInsert}>제&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;출</button>
                        </div>
                    </div>
                }
            </div>
        );
    }
}

decorate(ReadList, {
    packagetitle: observable,
    packagecontent: observable,
    packagenum: observable,
    quiznum: observable,
    quizlist: observable,
    quiz: observable,
    answer: observable,
    finalScore: observable,
    totalScore: observable,
    submitQuiz: observable,
    componentChange: observable,
    session: observable,
    uploadNum: observable,
    resultConfirm: observable,
    uploadList: observable,

    getQuizList: action,
    handleSubmit: action,
    handleInsert: action,
    linkFunction: action,
    confirm: action
  })

export default observer(ReadList);