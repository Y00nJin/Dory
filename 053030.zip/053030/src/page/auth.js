import React from 'react';

import { connect } from 'react-redux';
import { Login, Register } from 'containers/Auth';
import { Route } from 'react-router-dom';

class Auth extends React.Component {

    constructor(props) {
        super(props);
    }

    render() {
        return (
            <div>
                <Route path="/auth/login" component={Login}/>
                <Route path="/auth/register" component={Register}/>
            </div>
        );
    }
}

export default Auth;
/*
export default connect(
    (state) => ({

    }),
    (dispatch) => ({
        BaseActions: bindActionCreators(baseActions, dispatch)
    })
)(Auth);
*/