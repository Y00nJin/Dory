import React from 'react';
import { Link } from 'react-router-dom';
import PropTypes from 'prop-types';
import Quiz from './Quiz';
import 'whatwg-fetch';
import axios from 'axios';
import update from 'react-addons-update';

const Positioner = {
    position: 'absolute',
    left: '50%',
    transform: 'translate(-50%, 0)',
    marginTop:'3%', 
    textAlign:'center'
}

const linkDiv = {
    marginBottom: '1rem',
    textAlign: 'right',
    color: 'gray'
}


class QuizPage extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            items : 10,
            preItems : 0,
            loginData: {},
            list : [],
            listAll : [],
            delete: [],
            tag: false
        }

        this.getList = this.getList.bind(this);
        this.infiniteScroll = this.infiniteScroll.bind(this);
        this.filterList = this.filterList.bind(this);
        this.getSession = this.getSession.bind(this);
        this.handleDelete = this.handleDelete.bind(this);
        this.deleteCheck = this.deleteCheck.bind(this);
        this.tagClick = this.tagClick.bind(this);
        this.All = this.All.bind(this);

    }

    componentDidMount() {
        this.getList();
        this.getSession();
        window.addEventListener('scroll', this.infiniteScroll, true);
    }

    componentWillUnmount() {
        window.removeEventListener('scroll', this.infiniteScroll, true);
    }

    getList() {
        if(document.getElementById('search').value == ''){
            console.log(this.state.items);
            console.log(this.state.preItems);
            return axios.get('/api/board/quiz')
            .then((response) => {
                let result = response.data.results.slice(this.state.preItems,this.state.items);
                console.log(result);
                this.setState({
                    list : this.state.list.concat(result),
                    listAll : response.data.results
                });
                for(var i=0; i<response.data.results.length; i++){
                    this.setState({
                        delete : this.state.delete.concat({
                            num: response.data.results[i].num,
                            select: false
                            })
                        })
                    }
                return result;
            })
        } 
    }

    getSession() {
        function getCookie(name) {
            var value = "; " + document.cookie; 
            var parts = value.split("; " + name + "="); 
            if (parts.length == 2) return parts.pop().split(";").shift();
        }

        let loginData = getCookie('key');
        if(typeof loginData === "undefined") return;
        loginData = JSON.parse(atob(loginData));
        if(!loginData.isLoggedIn) return;

        console.log(loginData);

        this.setState({loginData: loginData});
    }

    filterList(e){
        if(e.target.value == ''){
            this.setState({
                items : 10,
                preItems : 0,
                list : [],
                delete : []
            });
            this.getList();
            return
        }
        var updatedList = this.state.listAll;
        updatedList = updatedList.filter( item => {
          return item.quizname.toLowerCase().search(
            e.target.value.toLowerCase()) !== -1;
        });
        this.setState({list: updatedList});
    }

    infiniteScroll() {
        if(document.getElementById('search').value == '' && !this.state.tag){
            let scrollHeight = Math.max(document.documentElement.scrollHeight, document.body.scrollHeight);

            let scrollTop = Math.max(document.documentElement.scrollTop, document.body.scrollTop);

            let clientHeight = document.documentElement.clientHeight;

            if(scrollTop + clientHeight === scrollHeight){
                console.log(this.state.items);
                console.log(this.state.preItems);
                this.setState({
                    preItems: this.state.items,
                    items: this.state.items+10
                })

                this.getList();
            }
        }
    }

    handleDelete() {
        const {onDelete} = this.props;
        for(var i=0; i<this.state.delete.length; i++){
            if(this.state.delete[i].select == true){
                let num = this.state.delete[i].num;
                axios.post('/api/board/quizDelete',{num})
                .then((response) => {
                    this.setState({
                        items : 10,
                        preItems : 0,
                        list : [],
                        delete:[]
                    });
                    this.getList();
                })
                .catch((err)=>{
                    console.log('Error fetching packageDelete',err);
                });
            }
        }
        onDelete();
    }

    deleteCheck(key) {
        this.setState({
            delete: update(
                this.state.delete,
                {
                    [key] : {
                        select: {$set: !this.state.delete[key].select}
                    }
                }
            )
        });

        console.log(this.state.delete);
    }

    tagClick(tag) {
        this.setState({
            tag: true,
            list: [],
            delete: []
        });
        axios.post('/api/board/selectTag',{tag})
        .then((response) => {
            this.setState({
                list : response.data.results
            });
            for(var i=0; i<response.data.results.length; i++){
                this.setState({
                    delete : this.state.delete.concat({
                        num: response.data.results[i].num,
                        select: false
                        })
                    })
                }
            })
        .catch((err)=>{
            console.log('Error fetching selectTag',err);
            });
    }

    All() {
        this.setState({
            items : 10,
            preItems : 0,
            list : [],
            delete : []
        });
        this.getList();
    }

    render() {
        const View = (
            this.state.list.map((data, i) => {
                return (<Quiz num={data.num}
                                arrayNum={i}
                                quizName={data.quizname}
                                tag={data.tag}
                                username={this.state.loginData._id}
                                deleteMode={this.props.deleteMode}
                                deleteFunction={this.deleteCheck}
                                tagC={this.tagClick}
                                key={i}/>);
                }
            )
        );
        return (
            <div>
                <div style={{textAlign: 'right'}}>
                    {this.props.deleteMode? <button className="singlebutton2 btn-1" onClick={this.handleDelete} style={{marginRight:'2em'}}>DELETE</button> : null}
                </div>
                <div style={Positioner}>
                    <a style={linkDiv} onClick={this.All}>[전체보기]</a>
                    <input type="text" id="search" className="form-control form-control-lg" placeholder="Search" onChange={this.filterList}/>
                    {View}
                </div>
            </div>
            
        );
    }
}

QuizPage.propTypes = {
    deleteMode: PropTypes.bool,
    onDelete: PropTypes.func
};
 
QuizPage.defaultProps = {
    deleteMode:false,
    onDelete: () => { console.error("onDelete function not defined"); }
};

export default QuizPage;