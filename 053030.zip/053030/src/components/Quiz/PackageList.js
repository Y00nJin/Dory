import React from 'react';
import { Link } from 'react-router-dom';
import PropTypes from 'prop-types';
import Package from './Package';
import 'whatwg-fetch';
import { connect } from 'react-redux';
import { getStatusRequest } from 'actions/authentication';
import axios from 'axios';
import update from 'react-addons-update';

const Positioner = {
    position: 'fixed',
    right:'0',
    top: '20%',
    width:'10%'
}

class PackageList extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            data: '',
            packageData: [],
            Alldata: [],
            loginData: {},
            delete: [],
            copy: []
        };

        this.getPacakageList = this.getPacakageList.bind(this);
        this.getSession = this.getSession.bind(this);
        this.deleteCheck = this.deleteCheck.bind(this);
        this.copyCheck = this.copyCheck.bind(this);
        this.handleDelete = this.handleDelete.bind(this);
        this.handleCopy = this.handleCopy.bind(this);
        this.mine = this.mine.bind(this);
        this.another = this.another.bind(this);
        this.exist = this.exist.bind(this);
        this.noneExist = this.noneExist.bind(this);
    }

    componentDidMount() {
        this.getPacakageList();
        this.getSession();
        //this.timer = setInterval(() => this.getPacakageList(), 1000);
    }

    /*
    componentWillUnmount() {
        this.timer = null;
    }  
    */

    getPacakageList() {
        fetch('/api/board/package')
		.then((response) => response.json())
		.then((response) => {
            let arr = response.data;
            let number = 0;
            arr = arr.map(
                info => ({
                    num: info.num,
                    title: info.title,
                    content: info.content,
                    id : number++
                })
            )
            this.setState({
                packageData: arr,
                Alldata: response.data,
                delete: response.data.map(
                    info => ({
                        num: info.num,
                        select: false
                    })
                ),
                copy: response.data.map(
                    info => ({
                        num: info.num,
                        select: false
                    })
                )
            });
            
		})
		.catch((err)=>{
			console.log('Error fetching package',err);
        });
        
    }

    mine() {
        let updatePackageData = this.state.Alldata.filter(info => info.id == this.state.loginData._id);
        let number = 0;
        updatePackageData = updatePackageData.map(
            info => ({
                num: info.num,
                title: info.title,
                content: info.content,
                id : number++
            })
        )
        this.setState({
            packageData: updatePackageData,
            delete: updatePackageData.map(
                info => ({
                    num: info.num,
                    select: false
                })
            ),
            copy: updatePackageData.map(
                info => ({
                    num: info.num,
                    select: false
                })
            )
          })
    }

    another() {
        let updatePackageData = this.state.Alldata.filter(info => info.id != this.state.loginData._id);
        let number = 0;
        updatePackageData = updatePackageData.map(
            info => ({
                num: info.num,
                title: info.title,
                content: info.content,
                id : number++
            })
        )
        this.setState({
            packageData: updatePackageData,
            delete: updatePackageData.map(
                info => ({
                    num: info.num,
                    select: false
                })
            ),
            copy: updatePackageData.map(
                info => ({
                    num: info.num,
                    select: false
                })
            )
          })
    }

    exist() {
        let id = this.state.loginData._id;
        let bool = true;
        axios.post('/api/board/exist',{id, bool})
		.then((response) => {
            let arr = response.data.result;
            let number = 0;
            arr = arr.map(
                info => ({
                    num: info.num,
                    title: info.title,
                    content: info.content,
                    id : number++
                })
            )
            this.setState({
                packageData: arr,
                delete: response.data.result.map(
                    info => ({
                        num: info.num,
                        select: false
                    })
                ),
                copy: response.data.result.map(
                    info => ({
                        num: info.num,
                        select: false
                    })
                )
            });
		})
		.catch((err)=>{
			console.log('Error fetching exist',err);
        });
    }

    noneExist() {
        let id = this.state.loginData._id;
        let bool = false;
        axios.post('/api/board/exist',{id, bool})
		.then((response) => {
            let arr = response.data.result;
            let number = 0;
            arr = arr.map(
                info => ({
                    num: info.num,
                    title: info.title,
                    content: info.content,
                    id : number++
                })
            )
            this.setState({
                packageData: arr,
                delete: response.data.result.map(
                    info => ({
                        num: info.num,
                        select: false
                    })
                ),
                copy: response.data.result.map(
                    info => ({
                        num: info.num,
                        select: false
                    })
                )
            });
		})
		.catch((err)=>{
			console.log('Error fetching exist',err);
        });
    }

    getSession() {
        function getCookie(name) {
            var value = "; " + document.cookie; 
            var parts = value.split("; " + name + "="); 
            if (parts.length == 2) return parts.pop().split(";").shift();
        }

        let loginData = getCookie('key');
        if(typeof loginData === "undefined") return;
        loginData = JSON.parse(atob(loginData));
        if(!loginData.isLoggedIn) return;

        console.log(loginData);

        this.setState({loginData: loginData});
    }

    deleteCheck(key) {
        this.setState({
            delete: update(
                this.state.delete,
                {
                    [key] : {
                        select: {$set: !this.state.delete[key].select}
                    }
                }
            )
        });

        console.log(this.state.delete);
    }

    copyCheck(num, arrayNum) {
        this.setState({
            copy : this.state.copy.map(
                info => num === info.num
                ? {
                    num: info.num,
                    select: !this.state.copy[arrayNum].select
                    }
                : {
                    num: info.num,
                    select: false
                    }
              )
        });
    }

    handleDelete(){
        const {onDelete} = this.props;
        for(var i=0; i<this.state.delete.length; i++){
            if(this.state.delete[i].select == true){
                let num = this.state.delete[i].num;
                axios.post('/api/board/packageDelete',{num})
                .then((response) => {
                    this.setState({
                        packageData:[],
                        delete:[]
                    });
                    this.getPacakageList();
                })
                .catch((err)=>{
                    console.log('Error fetching packageDelete',err);
                });
            }
        }

        onDelete();

    }

    handleCopy() {
        const { pageChange } = this.props;
        for(var i=0; i<this.state.copy.length; i++){
            if(this.state.copy[i].select == true){
                let num = this.state.copy[i].num;
                axios.post('/api/board/packageCopy',{num})
                .then((response) => {
                    const history = "/quiz/quizList/"+response.data.num;
                    pageChange(history);
                })
                .catch((err)=>{
                    console.log('Error fetching packageDelete',err);
                });
            }
        }
    }

    render() {
        const View = this.state.packageData.map(data => {
            return <Package num={data.num}
                        arrayNum={data.id}
                        packageName={data.title}
                        content={data.content}
                        username={this.state.loginData._id}
                        deleteMode={this.props.deleteMode}
                        copyMode={this.props.copyMode}
                        deleteFunction={this.deleteCheck}
                        copyFunction={this.copyCheck}
                        copySelect={this.state.copy}
                        key={data.num}/>
          });


        return (
            <div style={{marginTop:'30px'}}>
                <div style={{textAlign: 'right'}}>
                    {this.props.deleteMode? <button className="singlebutton2 btn-1" onClick={this.handleDelete} style={{marginRight:'2em'}}>DELETE</button> : null}
                    {this.props.copyMode? <button className="singlebutton2 btn-1" onClick={this.handleCopy} style={{marginRight:'2em'}}>COPY</button> : null}
                </div>
                <div style={{width:'90%'}}>{View}</div>
                <div style={Positioner}>
                    <button className="singlebutton3 btn-1" onClick={this.getPacakageList}>전체 보기</button>
                    <button className="singlebutton3 btn-1" onClick={this.mine}>내가 쓴 글</button>
                    <button className="singlebutton3 btn-1" onClick={this.another}>남이 쓴 글</button>
                    <button className="singlebutton3 btn-1" onClick={this.exist}>풀었던 문제</button>
                    <button className="singlebutton3 btn-1" onClick={this.noneExist}>풀지 않은 문제</button>
                </div>
            </div>
        );
    }
}

PackageList.propTypes = {
    num: PropTypes.num,
    deleteMode: PropTypes.bool,
    copyMode: PropTypes.bool,
    onDelete: PropTypes.func,
    pageChange: PropTypes.func
};
 
PackageList.defaultProps = {
    num: 0,
    deleteMode:false,
    copyMode:false,
    onDelete: () => { console.error("onDelete function not defined"); },
    pageChange: (history) => { console.error("pageChange function not defined"); }
};

const mapStateToProps = (state) => {
    return {
        status: state.authentication.status
    };
};
 
const mapDispatchToProps = (dispatch) => {
    return {
        getStatusRequest: () => {
            return dispatch(getStatusRequest());
        }
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(PackageList);