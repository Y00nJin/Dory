import React from 'react';
import { Link } from 'react-router-dom';
import PropTypes from 'prop-types';

class Menu extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            change : this.props.pageChange,
            loginData : {}
        };

        this.PageChange = this.PageChange.bind(this);
        this.getSession = this.getSession.bind(this);

    }

    PageChange() {
        const { onChange } = this.props;

        this.setState({
            change : !this.state.change
        });

        onChange();
    }

    componentDidMount(){
        this.getSession();
    }

    getSession() {
        function getCookie(name) {
            var value = "; " + document.cookie; 
            var parts = value.split("; " + name + "="); 
            if (parts.length == 2) return parts.pop().split(";").shift();
        }

        let loginData = getCookie('key');
        if(typeof loginData === "undefined") return;
        loginData = JSON.parse(atob(loginData));
        if(!loginData.isLoggedIn) return;

        console.log(loginData);

        this.setState({loginData: loginData});
    }

    render() {

        const PackageInsertButton = (
            <li>
                <a onClick={this.props.onInsert}>
                    <i className="material-icons" style={{color:'white', fontSize:'40px', right:'180px',bottom:'10px', position:'fixed'}}>create</i>
                </a>
                <a onClick={this.props.onDelete}>
                    <i className="material-icons" style={{color:'white', fontSize:'40px', right:'100px',bottom:'10px', position:'fixed'}}>delete_sweep</i>
                </a>
                <a onClick={this.props.onCopy}>
                    <i className="material-icons" style={{color:'white', fontSize:'40px', right:'20px',bottom:'10px', position:'fixed'}}>file_copy</i>
                </a>
            </li>
        );

        const username = this.state.loginData._id;
        let link_save = '/quiz/singleQuiz/'+null+'/'+username;

        const QuizInsertButton = (
            <li>
                <Link to={ link_save }>
                    <i className="material-icons" style={{color:'white', fontSize:'40px', right:'20px',bottom:'10px', position:'fixed'}}>create</i>
                </Link>
                <a onClick={this.props.onDelete}>
                    <i className="material-icons" style={{color:'white', fontSize:'40px', right:'100px',bottom:'10px', position:'fixed'}}>delete_sweep</i>
                </a>
            </li>
        );

        const QuizChange = (
            <li>
                <a onClick={this.PageChange}>
                    <i className="material-icons" style={{color:'white', fontSize:'40px', left:'20px',bottom:'10px', position:'fixed'}}>view_list</i>
                </a>
            </li>
        );
        const PackageChange = (
            <li>
                <a onClick={this.PageChange}>
                    <i className="material-icons" style={{color:'white', fontSize:'40px', left:'20px',bottom:'10px', position:'fixed'}}>view_module</i>
                </a>
            </li>
        );

        return (
            <div className="hihi">
                    <div className="header-wrap hi">
                        <ul>
                            { this.state.change ? QuizChange : PackageChange }
                            { this.state.change ? PackageInsertButton : QuizInsertButton }
                        </ul>
                    </div>
            </div>
        );
    }
}

Menu.propTypes = {
    onInsert: PropTypes.func,
    onChange: PropTypes.func,
    onCopy: PropTypes.func,
    onDelete: PropTypes.func,
    pageChange: PropTypes.bool
};
 
Menu.defaultProps = {
    onInsert: () => { console.error("Insert function not defined");},
    onChange: () => { console.error("Change function not defined");},
    onCopy: () => { console.error("Change function not defined");},
    onDelete: () => { console.error("Change function not defined");},
    pageChange: true,
};

export default Menu;
