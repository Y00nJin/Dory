import React, { Component } from 'react';
import { decorate, observable, action } from 'mobx';
import {observer} from "mobx-react"

const Wrapper = {
    width: '500px',
    marginTop: '1rem'
}


const ButtonStyle = {
    display: 'inline'
}


class ResultOption extends Component {

    constructor(props) {
        super(props);

        this.num = this.props.num;
        this.quizoption = this.props.content;
        this.check = this.props.check;
        this.dbcheck = this.props.dbcheck;
    }

    componentDidMount(){
        console.log(this.props.check);
    }

    render() {
        const check = (
            <div className="optionStyle" style={{textAlign:'right'}}>
                {this.dbcheck ? 
                    <i className="material-icons optionStyle" style={{fontSize:'15px', color:'green'}}>panorama_fish_eye</i>
                    :
                    <i className="material-icons optionStyle" style={{fontSize:'15px', color:'red'}}>clear</i>
                    }
            </div>
        );
        const optionView = (
            <div>
                <div style={Wrapper}>
                    {this.check ? 
                        <div style={{backgroundColor:'rgb(240, 233, 233)'}}>
                            <label onClick={this.handleAnswer} style={ButtonStyle} onChange={this.handleChange}>
                                <i className="material-icons optionStyle" style={{color:'gray'}}>radio_button_unchecked</i>
                            </label>
                            &nbsp;&nbsp;
                            <div id="option1" style={{width:'80%', fontSize:'17px', color:'gray'}} className="optionStyle">
                                {this.quizoption}
                            </div>
                            &nbsp;&nbsp;&nbsp;
                            {check}
                        </div>
                        :
                        <div>
                            <label onClick={this.handleAnswer} style={ButtonStyle} onChange={this.handleChange}>
                                <i className="material-icons optionStyle" style={{color:'gray'}}>radio_button_unchecked</i>
                            </label>
                            &nbsp;&nbsp;
                            <div id="option1" style={{width:'80%', fontSize:'17px', color:'gray'}} className="optionStyle">
                                {this.quizoption}
                            </div>
                            &nbsp;&nbsp;&nbsp;
                        </div>
                    }
                </div>
            </div>
        );

        return (
            <div>{ optionView }</div>
        );
    }
}

decorate(ResultOption, {
    num: observable,
    quizoption: observable,
    check: observable,
    dbcheck: observable

  })

export default observer(ResultOption);
