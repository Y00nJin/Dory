import React, { Component } from 'react';
import ResultOption from './ResultOption';
import axios from 'axios';
import { decorate, observable, action } from 'mobx';
import {observer} from "mobx-react"

// 너비, 그림자 설정
const ShadowedBox = {
    width: '600px',
    background: 'white'
}

// children 이 들어가는 곳
const Contents = {
    background: 'white',
    padding: '2rem',
    height: 'auto'
}

class ResultQuiz extends Component {

    constructor(props) {
        super(props);
        
        this.dbNum = null;
        this.number = this.props.num;
        this.quiztitle = '';
        this.value = 'select';
        this.quizoption = [];
        this.option = [];
        this.answerCheck = false;
        this.dbanswerCheck = false;

        this.getQuizList = this.getQuizList.bind(this);
    }
    
    componentDidMount(){
        this.getQuizList();
    }
    
    getQuizList() {
        const quizNum = this.props.content;
        this.dbNum = quizNum;
        const packagenum = this.props.packagenum;
        const id = this.props.id;

        axios.post('/api/board/quiztest', {quizNum})
		.then((response) => {
            this.quiztitle= response.data.quiz[0].quizname;
            this.quizoption= response.data.quiz[0].optionlist.split(',');
            this.value = response.data.quiz[0].tag;
            this.answer = response.data.quiz[0].answer.split('');
            this.score = response.data.quiz[0].score;
            
            axios.post('/api/board/selectResultNumber', {packagenum, id, quizNum})
            .then((response) => {
                this.resultAnswer= response.data.result[0].quiz_answer.split('');
                this.correct= response.data.result[0].correct;

                for(var i=0; i<this.quizoption.length; i++){
                    this.answerCheck = false;
                    for(var j=0; j<this.resultAnswer.length; j++){
                        if( i.toString() === this.resultAnswer[j] ) {
                            this.answerCheck = true;
                            break;   
                        }
                    }

                    this.dbanswerCheck = false;
                    for(var k=0; k<this.answer.length; k++){
                        if( i.toString() === this.answer[k] ) {
                            this.dbanswerCheck = true;
                            break;   
                        }
                    }
    
                    this.option = this.option.concat({
                        num: i,
                        content: this.quizoption[i],
                        check: this.answerCheck,
                        dbcheck: this.dbanswerCheck,
                        correct: this.correct
                        })
                }
                
            })
            .catch((err)=>{
                console.log('Error fetching packageClick',err);
            });
		})
		.catch((err)=>{
			console.log('Error fetching packageClick',err);
        });
    }

    render() {
        const quizContentView = (
            <div>
                <div>
                    {this.correct=='true' ? 
                       <div name="quiztitle" style={{fontSize:'25px', width:'70%', color:'green'}}
                       className="optionStyle"> O {this.quiztitle}</div>
                    :
                       <div name="quiztitle" style={{fontSize:'25px', width:'70%', color:'red'}}
                        className="optionStyle"> X {this.quiztitle}</div>
                    }
                </div>
            </div>
        );

        const optionList = this.option.map(
            ({num, content, check, dbcheck, correct}) => (
              <ResultOption
                num={num}
                content={content}
                check={check}
                dbcheck={dbcheck}
                correct={correct}
                key={num}
                optionCheck={this.optionCheck}
              />
            )
          );

        return (
            <div>
                <div style={ShadowedBox} className="card-3">
                   <div>
                    </div>
                    <div style={Contents}>
                        { quizContentView }
                        { optionList }
                    </div>
                </div>
            </div>
        );
    }
}

decorate(ResultQuiz, {
    dbNum: observable,
    answerCheck: observable, 
    dbanswerCheck: observable, 
    option: observable,
    quizoption: observable
  })

export default observer(ResultQuiz);