/*import React, { Component } from 'react';
import { PackageList } from 'components/Quiz/PackageList';
import { connect } from 'react-redux';
import { pacakageReadRequest } from 'actions/package';

class PackageContainer extends Component {

    constructor(props) {
        super(props);

        this.state = {
            packageData = []
        }
    }

    componentDidMount() {
        this.props.pacakageReadRequest().then(
            () => {
                if(this.props.status === "SUCCESS") {
                    // create session data
                    let loginData = {
                        isLoggedIn: true,
                        username: id
                    };
                    return true;
                } else {
                    return false;
                }
            }
        ).then((response) => response.json())
		.then((response) => {
			this.setState({packageData: response.data});
		})
		.catch((err)=>{
			console.log('Error fetching man',err);
        });
    }

    render() {
        return (
                <PackageList onInsert={this.handleInsert}/>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        status: state.packageList.packagelist.status
    };
};
 
const mapDispatchToProps = (dispatch) => {
    return {
        pacakageReadRequest: () => {
            return dispatch(pacakageReadRequest());
        }
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(PackageContainer);*/