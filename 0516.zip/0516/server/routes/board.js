import express from "express";
import conn from "../db/mysql.js";

const router = express.Router();

router.get('/package', (req, res) =>{
	conn.query("SELECT * FROM package ORDER BY num DESC", (err, results) => {
		if(err) {
			return res.send(err);
		}else {
			return res.json({
				data: results
			})
		}
	});
});

router.post("/packageInsert", (req, res) => {
	const pname = req.body.pname;
	const content = req.body.content;
	const loginId = req.body.loginData;
	console.log(loginId);
	let sql = "INSERT INTO package (title, content, id, total_score, final_score, count) VALUES(?,?,?,0,0,0)";
		  let post = [pname, content, loginId];
		  conn.query(sql, post, (err, results, fields) => {
			if (err) {
			  console.log(err);
			  return res.status(400).json({
				error: "db error"
			 });
			} else {
			  return res.status(200).json({
				success: true,
				error: null,
				num : results.insertId
			  });
			}
		  });
	});

	router.post("/packageDelete", (req, res) => {
		console.log(req.body.num);
		const pname = req.body.num;

		let sql = "DELETE FROM package WHERE num=?";
		let post = [pname];
		conn.query(sql, post, (err, results, fields) => {
			if (err) {
				console.log(err);
				return res.status(400).json({
				error: "db error"
				});
			} else {
					return res.status(200).json({
					success: true,
					error: null,
				});
			}
		});
	});

	router.post("/packageCopy", (req, res) => {
		console.log(req.body.num);
		const pname = req.body.num;

		let sql = "INSERT INTO package (title, content, quizlist, id, count, total_score, final_score) " 
		+ "SELECT CONCAT(title,'(2)'), content, quizlist, id, 0, 0, 0 FROM package where num = ?";
		let post = [pname];
		conn.query(sql, post, (err, results, fields) => {
			if (err) {
				console.log(err);
				return res.status(400).json({
				error: "db error"
				});
			} else {
					return res.status(200).json({
						num : results.insertId
				});
			}
		});
	});

	router.get("/packageClick", (req, res) => {
		const package_num = req.query.num;
		let sql = "SELECT * FROM package WHERE num=?";
		
    let post = [package_num];

    conn.query(sql, post, (err, results) => {
      if (err) { 
				throw err
			}
      else {
				return res.status(200).json({
					package: results
				})
			}  
    });
	})
	
	router.post("/finalUpdate", (req, res) => {

		const packagenum = req.body.packagenum1;

		let sql = "UPDATE package SET final_score = 0 WHERE num = ?";
				let post = [packagenum];
				conn.query(sql, post, (err, results, fields) => {
				if (err) {
					console.log(err);
					return res.status(400).json({
					error: "db error"
				 });
				} else {
					return res.status(200).json({
					success: true,
					error: null
					});
				}
				});
		});

	router.post("/packageUpdate", (req, res) => {
		const packagenum = req.body.packagenum;
		const quizlist = req.body.quizlist;
		const final_score = req.body.score;
		const title = req.body.title;
		const content = req.body.content;
		console.log(final_score);

		let sql = "UPDATE package SET title = ?, content = ?, quizlist = ?, final_score = final_score + ? WHERE num = ?";
				let post = [title, content, quizlist, final_score, packagenum];
				conn.query(sql, post, (err, results, fields) => {
				if (err) {
					console.log(err);
					return res.status(400).json({
					error: "db error"
				 });
				} else {
					return res.status(200).json({
					success: true,
					error: null
					});
				}
				});
		});

	router.post("/quizInsert", (req, res) => {
		const quizname = req.body.title;
		const optionlist = req.body.option;
		const tag = req.body.val;
		const answer = req.body.answer;
		const score = req.body.score;
		const bool = req.body.bool;
		const id = req.body.username;

		if(bool==false){
			return res.status(200).json({
				num: null
			 });
		}

		let sql = "INSERT INTO quiz (quizname, optionlist, tag, answer, score, id) VALUES(?,?,?,?,?,?)";
				let post = [quizname, optionlist, tag, answer, score, id];
				conn.query(sql, post, (err, results, fields) => {
				if (err) {
					console.log(err);
					return res.status(400).json({
					error: "db error"
				 });
				} else {
					console.log(results.insertId);
					return res.status(200).json({
						num : results.insertId
					});
				}
				});
		});

		router.post("/quizInsert2", (req, res) => {
			const quizname = req.body.title;
			const optionlist = req.body.option;
			const tag = req.body.val;
			const answer = req.body.answer;
			const score = req.body.score;
			const dbnum = req.body.dbnum;
			const id = req.body.id;
	
			console.log(quizname);
			console.log(optionlist);
			console.log(tag);
			console.log(answer);
			console.log(score);
			console.log(dbnum);

			let sqlTest = "SELECT * FROM quiz WHERE num = ?";
			let postTEST = [dbnum];
			conn.query(sqlTest, postTEST, (err, results) => {
				if (results.length === 0) {
					let sql = "INSERT INTO quiz (quizname, optionlist, tag, answer, score, id) VALUES(?,?,?,?,?,?)";
					let post = [quizname, optionlist, tag, answer, score, id];
					conn.query(sql, post, (err, results, fields) => {
						if (err) {
							console.log(err);
							return res.status(400).json({
								error: "db error"
							});
						} else {
							return res.status(200).json({
								num : results.insertId
							});
						}
					});
				}else{
					let sql = "UPDATE quiz SET quizname = ?, optionlist = ?, tag = ?, answer = ?, score = ? WHERE num = ?";
					let post = [quizname, optionlist, tag, answer, score, dbnum];
					conn.query(sql, post, (err, results, fields) => {
						if (err) {
							console.log(err);
							return res.status(400).json({
								error: "db error"
							});
						} else {
							return res.status(200).json({
								num : results.insertId
							});
						}
					});
				}
			})

			
			});

	router.get('/quiz', (req, res) =>{
		conn.query("SELECT * FROM quiz ORDER BY num DESC", (err, results) => {
			if(err) {
				return res.send(err);
			}else {
				return res.json({
					results
				})
			}
		});
	});

	router.post("/selectQuiz", (req, res) => {
		const quizKey = req.body.dbnum;
		let sql = "SELECT * FROM quiz WHERE num = ?";
		let post = [quizKey];
		console.log(quizKey);
		conn.query(sql, post, (err, results, fields) => {
			if (err) { 
				throw err
			} else {
				return res.status(200).json({
					quiz : results
				});
			}
			});
		});

		router.post('/quiztest', (req, res) =>{
			const quizKey = req.body.quizNum;

			let sql = "SELECT * FROM quiz WHERE num = ?";
			let post = [quizKey];
			conn.query(sql, post, (err, results) => {
				if(err) {
					return res.send(err);
				}else {
					return res.json({
						quiz: results
					})
				}
			});
		});

		router.post("/quizDelete", (req, res) => {
			console.log(req.body.num);
			const num = req.body.num;
	
			let sql = "DELETE FROM quiz WHERE num=?";
			let post = [num];
			conn.query(sql, post, (err, results, fields) => {
				if (err) {
					console.log(err);
					return res.status(400).json({
					error: "db error"
					});
				} else {
						return res.status(200).json({
						success: true,
						error: null,
					});
				}
			});
		});

		router.post("/countUpdate", (req, res) => {
			const package_number = req.body.pknum;
			let sql = "UPDATE package SET count = count + 1 WHERE num = ?";
			let post = [package_number];
					conn.query(sql, post, () => {
						return 0
					});
			});

		router.post("/resultInsert", (req, res) => {
			const package_number = req.body.pknum;
			const quiz_number = req.body.dbnum;
			const email = req.body.email;
			const quiz_answer = req.body.answer;
			const correct = req.body.correct;
			const total_score = req.body.total_score;

			let sql = "INSERT INTO result (package_number, quiz_number, email, quiz_answer, correct) VALUES(?,?,?,?,?)"+
			"ON DUPLICATE KEY UPDATE quiz_answer = VALUES(quiz_answer), correct = VALUES(correct)";
			let post = [package_number, quiz_number, email, quiz_answer, correct];

			let sql2 = "UPDATE package SET total_score = total_score + ? WHERE num = ?";
			let post2 = [total_score, package_number];

					conn.query(sql, post, (err, results, fields) => {
					if (err) {
						console.log(err);
						return res.status(400).json({
						error: "db error"
					 });
					} else {
						console.log(results.insertId);
						conn.query(sql2, post2);
						return res.status(200).json({
							num : results.insertId
						});
					}
					});
			});


			router.post("/singleresultInsert", (req, res) => {
				const quiz_number = req.body.dbnum;
				const email = req.body.email;
				const quiz_answer = req.body.answer;
				const correct = req.body.correct;
	
				let sql = "INSERT INTO result (quiz_number, email, quiz_answer, correct) VALUES(?,?,?,?)";
				let post = [quiz_number, email, quiz_answer, correct];
	
				conn.query(sql, post, (err, results, fields) => {
					if (err) {
						console.log(err);
						return res.status(400).json({
						error: "db error"
					 });
					} else {
						console.log(results.insertId);
						return res.status(200).json({
							num : results.insertId
						});
					}
					});
			});
/*
			router.post("/resultGroupInsert", (req, res) => {
				const package_number = req.body.pknum;
				const email = req.body.email;
	
				let sql = "INSERT INTO result_group (package_number, email) VALUES(?,?)";
						let post = [package_number, email];
						conn.query(sql, post, (err, results, fields) => {
						if (err) {
							console.log(err);
							return res.status(400).json({
							error: "db error"
						 });
						} else {
							console.log(results.insertId);
							return res.status(200).json({
								num : results.insertId
							});
						}
					});
			});

			router.post("/resultGroupUpdate", (req, res) => {
				const num = req.body.resultNum;
				const list = req.body.uploadList;

				let sql = "UPDATE result_group SET result_number = ? WHERE num = ?";
						let post = [list, num];
						conn.query(sql, post, (err, results, fields) => {
						if (err) {
							console.log(err);
							return res.status(400).json({
							error: "db error"
						});
						} else {
							return res.status(200).json({
								num : results.insertId
							});
						}
						});
				});
*/
			router.post("/selectResultGroup", (req, res) => {
				const rnum = req.body.rnum;
				let sql = "SELECT * FROM result_group WHERE num = ?";
				let post = [rnum];
				conn.query(sql, post, (err, results, fields) => {
					if (err) { 
						throw err
					} else {
						return res.status(200).json({
							result_group : results
						});
					}
					});
				});

			router.get("/selectEmailResultGroup", (req, res) => {
				const email = req.query.email;
				let sql = "SELECT * FROM result_group WHERE email = ?";
				let post = [email];
				conn.query(sql, post, (err, results, fields) => {
					if (err) { 
						throw err
					} else {
						return res.status(200).json({
							results
						});
					}
					});
				});

			router.post("/selectResult", (req, res) => {
				const rnum = req.body.resultNum;
				let sql = "SELECT * FROM result WHERE num = ?";
				let post = [rnum];
				conn.query(sql, post, (err, results, fields) => {
					if (err) { 
						throw err
					} else {
						return res.status(200).json({
							result : results
						});
					}
					});
				});

			router.post("/selectResultNumber", (req, res) => {
				const start = req.body.start;
				const end = req.body.end;
				const quiznum = req.body.quiznum;
				let sql = "SELECT num FROM result WHERE num >= ? and num <= ? and quiz_number = ?";
				let post = [start, end, quiznum];
				conn.query(sql, post, (err, results, fields) => {
					if (err) { 
						throw err
					} else {
						return res.status(200).json({
							result : results
						});
					}
					});
				});

export default router;
