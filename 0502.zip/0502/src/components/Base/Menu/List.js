import { MDBTable, MDBTableBody, MDBTableHead } from 'mdbreact';
import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import PropTypes from 'prop-types';
import axios from 'axios';

class List extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            items : 20,
            preItems : 0,
            preCoverUrl : '',
            coverurl : '',

            list : []
        }

        this.getList = this.getList.bind(this);
        this.infiniteScroll = this.infiniteScroll.bind(this);

    }

    componentDidMount() {
        this.getList();
        window.addEventListener('scroll', this.infiniteScroll, true);
    }

    getList() {
        return axios.get('/api/board/selectEmailResultGroup', {
            params: {
                email: 'qkr030@naver.com'
            }
        })
        .then((response) => {
            let result = response.data.results.slice(this.state.preItems,this.state.items);
            console.log(result);
            this.setState({
                list : this.state.list.concat(result)
            });
            return result;
        })
    }

    infiniteScroll() {
        let scrollHeight = Math.max(document.documentElement.scrollHeight, document.body.scrollHeight);

        let scrollTop = Math.max(document.documentElement.scrollTop, document.body.scrollTop);

        let clientHeight = document.documentElement.clientHeight;

        if(scrollTop + clientHeight === scrollHeight){
            console.log(this.state.items);
            console.log(this.state.preItems);
            this.setState({
                preItems: this.state.items,
                items: this.state.items+20
            })

            this.getList();
        }
    }

    render(){
        
        const tableData = this.state.list.map(
            data => (
                <tr>
                    <td>{data.num}</td>
                    <td>{data.package_number}</td>
                    <td>{data.email}</td>
                    <td>{data.result_number}</td>
              </tr>
            )
          );

          
        return (
            <MDBTable hover>
              <MDBTableHead>
                <tr>
                  <th>#</th>
                  <th>First</th>
                  <th>Last</th>
                  <th>Handle</th>
                </tr>
              </MDBTableHead>
              <MDBTableBody>
                {tableData}
              </MDBTableBody>
            </MDBTable>
          );
    }
}

export default List;