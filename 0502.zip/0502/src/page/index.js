// 내보낼 컴포넌트 정리
//import Home from './home';
//import Auth from './auth';

//export { Home, Auth };

export { default as Home } from './home';
export { default as Auth } from './auth';
export { default as Quiz } from './quiz';
