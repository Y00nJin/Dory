import React from 'react';
import { QuizList, fail, QuizPlus, SingleQuiz } from 'components/Quiz';
import ReadList from 'components/ReadQuiz/ReadList';
import SingleRead from 'components/ReadQuiz/SingleRead';
import { Route } from 'react-router-dom';
import MenuContainer from 'containers/Base/MenuContainer';
import { List } from 'components/Base/Menu';

class Quiz extends React.Component {

    constructor(props) {
        super(props);
    }

    render() {
        return (
            <div>
                <Route path="/quiz/packageList" component={MenuContainer}/>
                <Route path="/quiz/List" component={List}/>
                <Route path="/quiz/fail" component={fail}/>
                <Route path="/quiz/quizplus" component={QuizPlus}/>
                <Route path="/quiz/quizList/:num" component={QuizList}/>
                <Route path="/quiz/read/:num" component={ReadList}/>
                <Route path="/quiz/singleQuiz/:num" component={SingleQuiz}/>
                <Route path="/quiz/singleRead/:num" component={SingleRead}/>

            </div>
        );
    }
}

export default Quiz;
