import React from 'react';
import { Link } from 'react-router-dom';
import PropTypes from 'prop-types';
import Quiz from './Quiz';
import 'whatwg-fetch';
import axios from 'axios';

const Positioner = {
    position: 'absolute',
    left: '50%',
    transform: 'translate(-50%, 0)',
    marginTop:'3%', 
    textAlign:'center'
}

class QuizPage extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            items : 10,
            preItems : 0,
            loginData: {},
            list : [],
            listAll : []
        }

        this.getList = this.getList.bind(this);
        this.infiniteScroll = this.infiniteScroll.bind(this);
        this.filterList = this.filterList.bind(this);
        this.getSession = this.getSession.bind(this);

    }

    componentDidMount() {
        this.getList();
        this.getSession();
        window.addEventListener('scroll', this.infiniteScroll, true);
    }

    componentWillUnmount() {
        window.removeEventListener('scroll', this.infiniteScroll, true);
    }

    getList() {
        if(document.getElementById('search').value == ''){
            console.log(this.state.items);
            console.log(this.state.preItems);
            return axios.get('/api/board/quiz')
            .then((response) => {
                let result = response.data.results.slice(this.state.preItems,this.state.items);
                console.log(result);
                this.setState({
                    list : this.state.list.concat(result),
                    listAll : response.data.results
                });
                return result;
            })
        } 
    }

    getSession() {
        function getCookie(name) {
            var value = "; " + document.cookie; 
            var parts = value.split("; " + name + "="); 
            if (parts.length == 2) return parts.pop().split(";").shift();
        }

        let loginData = getCookie('key');
        if(typeof loginData === "undefined") return;
        loginData = JSON.parse(atob(loginData));
        if(!loginData.isLoggedIn) return;

        console.log(loginData);

        this.setState({loginData: loginData});
    }

    filterList(e){
        if(e.target.value == ''){
            this.setState({
                items : 10,
                preItems : 0,
                list : []
            });
            this.getList();
            return
        }
        var updatedList = this.state.listAll;
        updatedList = updatedList.filter( item => {
          return item.quizname.toLowerCase().search(
            e.target.value.toLowerCase()) !== -1;
        });
        this.setState({list: updatedList});
    }

    infiniteScroll() {
        if(document.getElementById('search').value == ''){
            let scrollHeight = Math.max(document.documentElement.scrollHeight, document.body.scrollHeight);

            let scrollTop = Math.max(document.documentElement.scrollTop, document.body.scrollTop);

            let clientHeight = document.documentElement.clientHeight;

            if(scrollTop + clientHeight === scrollHeight){
                console.log(this.state.items);
                console.log(this.state.preItems);
                this.setState({
                    preItems: this.state.items,
                    items: this.state.items+10
                })

                this.getList();
            }
        }
    }

    render() {
        const View = (
            this.state.list.map((data, i) => {
                return (<Quiz num={data.num}
                                quizName={data.quizname}
                                tag={data.tag}
                                username={this.state.loginData._id}
                                key={i}/>);
                }
            )
        );
        return (
            <div style={Positioner}>
                <input type="text" id="search" className="form-control form-control-lg" placeholder="Search" onChange={this.filterList}/>
                {View}
            </div>
        );
    }
}

QuizPage.propTypes = {
};
 
QuizPage.defaultProps = {
};

export default QuizPage;