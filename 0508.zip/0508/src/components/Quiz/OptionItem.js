import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import PropTypes from 'prop-types';
import { decorate, observable, action } from 'mobx';
import {observer} from "mobx-react"

const Wrapper = {
    marginTop: '1rem'
}


const ButtonStyle = {
    cursor: 'pointer',
    display: 'inline'
}


class OptionItem extends Component {

    constructor(props) {
        super(props);

        this.num = this.props.num;
        this.quizoption = this.props.content;
        this.check = this.props.check;

        this.handleChange = this.handleChange.bind(this);
        this.handleDelete = this.handleDelete.bind(this);
        this.handleAnswer = this.handleAnswer.bind(this);
        this.click = this.click.bind(this);


    }

    componentDidUpdate() {
        const { onoptionChange } = this.props;
        onoptionChange(this.num, this.quizoption, this.check);
      }

    handleChange(e){
        this[e.target.name] = e.target.value;
    }

    handleDelete(){
        const { onDelete } = this.props;
        onDelete(this.num);
    }

    handleAnswer(){
        this.check = !this.check;
    }

    click(){
        console.log(this.props.num);
        console.log(this.props.content);
    }
    
    render() {

        const optionView = (
            <div>
                <div style={Wrapper}>
                    <label onClick={this.handleAnswer} style={ButtonStyle} onChange={this.handleChange}>
                        { this.check ? 
                        <i className="material-icons optionStyle" style={{color:'red'}}>check_circle_outline</i>
                        :
                        <i className="material-icons optionStyle" style={{color:'gray'}}>radio_button_unchecked</i>
                        }
                    </label>
                    &nbsp;&nbsp;
                    <input name="quizoption" placeholder="옵션" type="text" style={{fontSize:'20px', width:'80%', color:'gray'}}
                        onChange={this.handleChange}
                        onClick={this.click}
                        value={this.quizoption} 
                        className="optionStyle"/> 
                    &nbsp;&nbsp;&nbsp;
                    <div style={ButtonStyle} onClick={this.handleDelete}><i className="material-icons optionStyle" style={{color:'gray'}}>delete</i></div>
                </div>
            </div>
        );

        return (
            <div>{ optionView }</div>
        );
    }
}

OptionItem.propTypes = {
    onDelete: PropTypes.func,
    onoptionChange: PropTypes.func
};
 
OptionItem.defaultProps = {
    onDelete: (number) => { console.error("Delete function not defined"); },
    onoptionChange: (number) => { console.error("optionChange function not defined"); }
};

decorate(OptionItem, {
    num: observable,
    quizoption: observable,
    check: observable,
    handleChange: action,
    handleAnswer: action,
    handleDelete: action,
    click: action
  })

export default observer(OptionItem);