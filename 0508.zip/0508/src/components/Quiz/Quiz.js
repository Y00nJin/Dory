import React from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';


const Title = {
    fontSize: '1.5rem',
    fontWeight: '500',
    color: '#ef5d62',
    background: 'white',
    textAlign: 'center',
    display: 'inline'
}

const Wrapper = {
    marginTop: '1.5rem',
    width: '400px',
    height: '70px',
    background: 'white'
}

const Label = {
    fontSize: '1rem',
    color: 'gray',
    marginBottom: '0.25rem',
    textAlign: 'center',
    display: 'inline'
}

class Quiz extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            bool : false
        }
    }

    componentDidMount() {
        const { num, username } = this.props;
        const dbnum = num;
        axios.post('/api/board/selectQuiz',{dbnum})
		.then((response) => {
            const id = response.data.quiz[0].id
            if(id==username){
                this.setState({
                    bool : true 
                });
            }
		})
		.catch((err)=>{
			console.log('Error fetching packageClick',err);
        });
    }

    render() {
        const { num } = this.props;
        let link_save = '/quiz/singleQuiz/' + num ;
        let link_read = '/quiz/singleRead/' + num ;
        const QuizView = (
            <div>
                <div style={Wrapper} className="card-1">
                    <div style={Title}><b>{this.props.quizName}</b></div>
                    <div style={Label}>{this.props.tag}</div>
                </div>
            </div>
        );

        return (
            <div>
                <Link to={ this.state.bool ? link_save : link_read }>
                    {QuizView}
                </Link>
            </div>
        );
    }
}


export default Quiz;