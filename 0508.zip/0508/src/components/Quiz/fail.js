import React, { Component } from 'react';
import { Link } from 'react-router-dom';

const Wrapper = {
    marginTop: '3rem',
    paddingBottom:'3rem'
}

const Positioner2 = {
    position: 'absolute',
    left: '50%',
    top: '30%',
    transform: 'translate(-50%, 0)'
}

// 너비, 그림자 설정
const ShadowedBox = {
    width: '500px',
    marginTop: '1rem'
}

const LogoWrapper2 = {
    background: '#ffcc00',
    height: '4rem',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center'
}

const Logo = {
    color: 'white',
    fontFamily: 'Rajdhani',
    fontSize: '1.7rem',
    textDecoration: 'none'
}

const linkDiv = {
    color: 'gray',
    cursor: 'pointer'
}

class fail extends Component {

    constructor(props) {
        super(props);
    }

    linkFunction(){
        
    }

    render() {

        const View = (
            <div style={Positioner2}>
                <div style={ShadowedBox} className="card-3">
                    <div style={LogoWrapper2}>
                        <div style={Logo}>
                            <b>WARNING</b>
                        </div>
                    </div>
                    <div style={Wrapper}>
                        <div style={{fontSize:'20px', textAlign:'center'}}>
                            <span style={{color:'gray'}}>로그인이 필요한 서비스입니다.</span>
                        </div>
                    </div>
                </div>
                <div style={{textAlign:"right",marginTop: '0.5rem'}}><Link to='/auth/login' style={linkDiv}>SignIN</Link></div>
            </div>
        );

        return (
            <div>
                { View }
            </div>
        );
    }
}

export default fail;