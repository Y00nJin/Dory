import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import PropTypes from 'prop-types';
import OptionItem from './OptionItem';
import axios from 'axios';
import update from 'react-addons-update';
import { decorate, observable, action } from 'mobx';
import {observer} from "mobx-react"

const Wrapper = {
    marginTop: '1rem'
}

// 너비, 그림자 설정
const ShadowedBox = {
    width: '600px',
    background: 'white'
}

// 로고
const LogoWrapper = {
    background: '#ef5d62',
    border:'2px solid #ef5d62',
    height: '1rem',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center'
}

const Logo = {
    color: '#ef5d62',
    fontFamily: 'Rajdhani',
    fontSize: '1.5srem',
    letterSpacing: '5px',
    textDecoration: 'none'
}

// children 이 들어가는 곳
const Contents = {
    background: 'white',
    padding: '2rem',
    height: 'auto'
}

const ButtonStyle = {
    cursor: 'pointer',
    display: 'inline',
    color:'rgb(255, 106, 106)'
}

const Positioner = {
    position: 'absolute',
    left: '50%',
    top: '50%',
    transform: 'translate(-50%, -50%)'
}

class SingleQuiz extends Component {

    constructor(props) {
        super(props);

        this.state = {
            option : []
        };

        this.num = 0;
        this.numnum = 0;

        this.number = this.props.num;
        this.quiztitle = '';
        this.value = 'select';
        this.quizoption = [];
        this.dbNum = null;
        this.score = 1;
        this.optionlist = '';

        this.handleChange = this.handleChange.bind(this);
        this.handleCreate = this.handleCreate.bind(this);
        this.handledelete = this.handledelete.bind(this);
        this.handleoptionChange = this.handleoptionChange.bind(this);
        this.list = this.list.bind(this);
        this.handleInsert = this.handleInsert.bind(this);

    }
    
    componentDidMount(){
        this.getQuizList();
    }
    
    getQuizList() {
        const quizNum = this.props.match.params.num;
        if(quizNum!=null){
            this.dbNum = quizNum;
            axios.post('/api/board/quiztest', {quizNum})
            .then((response) => {
                this.quiztitle= response.data.quiz[0].quizname;
                this.quizoption= response.data.quiz[0].optionlist.split(',');
                this.value = response.data.quiz[0].tag;
                this.answer = response.data.quiz[0].answer.split('');
                this.score = response.data.quiz[0].score;

                for(var i=0; i<this.quizoption.length; i++){
                    var answerCheck = false;
                    for(var j=0; j<this.answer.length; j++){
                        if( this.num.toString() === this.answer[j] ) {
                            answerCheck = true;
                            break;   
                        }
                    }
                    this.setState({
                        option : this.state.option.concat({
                            num: this.num++,
                            content: this.quizoption[i],
                            check: answerCheck
                            })
                    });
                    this.numnum++;
                }
            })
            .catch((err)=>{
                console.log('Error fetching quiztest',err);
            });
        }
    }
    /*
    componentDidUpdate(){
        const { onUpload } = this.props;
        onUpload(this.dbNum, this.number, this.quiztitle, this.state.option, this.value, this.score);
    }
    */

    handleChange(e){
        this[e.target.name] = e.target.value;
    }

    handleCreate(){
        this.setState({
            option : this.state.option.concat({
                num: this.num++,
                content: '',
                check: false
            })
        });
        this.numnum++;
    }

    handledelete(number){
        if(this.numnum>0){
            this.numnum--;
        }

        console.log(number);

        this.setState({
            option: this.state.option.filter(info => info.num !== number)
          })

    }
    
    handleoptionChange(number, optioncontent, check) {
        this.setState({
            option : this.state.option.map(
                info => number === info.num
                ? {
                    num: number,
                    content: optioncontent,
                    check: check
                    }
                : info
              )
        });
    }

    list() {
        this.props.history.push('/quiz/packageList');
    }

    handleInsert() {

        this.answer = '';

        for(var j=0; j<this.state.option.length; j++){ // 답안 번호

            if(j!=this.state.option.length-1){
                this.optionlist = this.optionlist + this.state.option[j].content + ',';    
            }else{
                this.optionlist += this.state.option[j].content;
            }

            if(this.state.option[j].check){
                this.answer += j.toString();
            }
        }

        const dbnum = this.dbNum;
        const title = this.quiztitle;
        const option = this.optionlist;
        const val = this.value;
        const answer = this.answer;
        const score = this.score;

        axios.post('/api/board/quizInsert2',{dbnum, title, option, val, answer, score})
            .then((response) => {
                
            })

        Materialize.toast('Success!', 2000);
        this.props.history.push('/quiz/packageList');
    }
    render() {
        const quizContentView = (
            <div>
                <div>
                    <input name="quiztitle" placeholder="질문" type="text" style={{fontSize:'30px', width:'70%', color:'gray', placeholder:'gray'}}
                    onChange={this.handleChange}
                    value={this.quiztitle}
                    className="optionStyle"/>
                    <div className="optionStyle">
                        <label htmlFor="select1" className="optionStyle" style={{fontSize:'40px', color:'darkGray'}}><b>#</b></label>
                        <input type="text" placeholder="#tag 형식" name="value" value={this.value} onChange={this.handleChange} className="optionStyle"
                        style={{fontSize:'15px', width:'20%', color:'gray', placeholder:'gray'}}/>
                    </div>
                </div>
            </div>
        );

        const buttonView = (
                <span style={Wrapper}>
                    <i className="material-icons optionStyle" style={ButtonStyle}>radio_button_unchecked</i>
                    &nbsp;&nbsp;
                    <input type="text" style={{fontSize:'15px', width:'50%', color:'rgb(255, 106, 106)', borderColor:'rgb(255, 106, 106)'}}
                        value='옵션 추가'
                        className="optionStyle"
                        disabled/> 
                    &nbsp;&nbsp;&nbsp;
                </span>
        );


        const optionList = this.state.option.map(
            data => (
              <OptionItem
                num={data.num}
                content={data.content}
                check={data.check}
                key={data.num}
                onDelete={this.handledelete}
                onoptionChange={this.handleoptionChange}
              />
            )
          );

        return (
            <div style={Positioner}>
                <div style={ShadowedBox} className="card-2">
                   <div style={LogoWrapper}>
                        <div style={Logo}></div>
                    </div>
                    <div style={Contents}>
                        { quizContentView }
                        { optionList }
                        <div style={{marginTop: '1.5rem'}}>
                            <span onClick={this.handleCreate}> 
                                { this.numnum <= 10 ? buttonView : null } 
                            </span>
                            <span style={{color:'gray', marginLeft:'15%'}} >
                                <b>점수</b>&nbsp;&nbsp;&nbsp;
                                <input type="number" min="1" max="10" step="1" className="optionStyle" style={{width:'8%'}}
                                    name="score" value={this.score}
                                    onChange={this.handleChange}/>
                            </span>
                        </div>
                    </div>
                </div>
                <div style={{textAlign: 'right'}}>
                    <button className="singlebutton btn-1" onClick={this.list}>LIST</button>
                    <button className="singlebutton2 btn-1" onClick={this.handleInsert}>SAVE</button>
                </div>
            </div>
        );
    }
}

decorate(SingleQuiz, {
    num : observable,
    numnum : observable,
    quizoption : observable,
    number : observable,
    quiztitle : observable,
    value : observable,
    quizoption: observable,
    dbNum : observable,
    score : observable,
    optionlist : observable,

    handleCreate : action,
    handleoptionChange : action
  })

export default observer(SingleQuiz);