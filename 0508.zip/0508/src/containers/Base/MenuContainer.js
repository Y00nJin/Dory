import React, { Component } from 'react';
import { Menu, InsertPakage } from 'components/Base/Menu';
import { connect } from 'react-redux';
import { packageRequest } from 'actions/package';
import { PackageList, QuizPage } from 'components/Quiz';
//import { Redirect } from 'react-router'

const Positioner = {
    position: 'absolute',
    left: '50%',
    transform: 'translate(-50%, 0)'
}

class MenuContainer extends Component {

    constructor(props) {
        super(props);

        this.state = {
            isHover: false,
            pageChange: true,
            copyMode: false,
            deleteMode: false
        }

        this.handleInsert = this.handleInsert.bind(this);
        this.handlePackageInsert = this.handlePackageInsert.bind(this);
        this.handleChange = this.handleChange.bind(this);
        this.handleCopy = this.handleCopy.bind(this);
        this.handleDelete = this.handleDelete.bind(this);
        this.copyChange = this.copyChange.bind(this);

    }

    handleInsert(){
        this.setState({
            isHover: !this.state.isHover
        });
    }

    handleChange(){
        this.setState({
            pageChange: !this.state.pageChange
        });
    }

    handlePackageInsert(pn, pc, loginData){
        return this.props.packageRequest(pn, pc, loginData).then(
            (response) => {
                if(this.props.status === "SUCCESS") {
                    console.log(response);
                    Materialize.toast('Success!', 2000);
                    const add = "/quiz/quizList/"+response;
                    this.props.history.push(add);
                    //<Redirect to={add}/>
                    //window.location.href = "http://localhost:3000/quiz/quizList/"+response;
                    return true;
                } else {
                    let $toastContent = $('<span style="color: #FFB4BA">Try again.</span>');
                    Materialize.toast($toastContent, 2000);
                    return false;
                }
            }
        );
    }

    handleCopy(){
        this.setState({
            copyMode: !this.state.copyMode,
            deleteMode: false
        });
    }

    copyChange(history){
        Materialize.toast('Success!', 2000);
        this.props.history.push(history);
    }

    handleDelete(){
        this.setState({
            deleteMode: !this.state.deleteMode,
            copyMode: false
        });
    }

    render() {

        return (
            <div>
                {this.state.isHover ? <InsertPakage onPackageInsert={this.handlePackageInsert}/> : null }
                <Menu onInsert={this.handleInsert} onChange={this.handleChange} onCopy={this.handleCopy} onDelete={this.handleDelete}/>
                {this.state.pageChange ? <PackageList copyMode={this.state.copyMode} deleteMode={this.state.deleteMode} onDelete={this.handleDelete} pageChange={this.copyChange}/> : <QuizPage/>}
            </div>
        );
    }
}

const mapStateToProps = (state) => {
    return {
        status: state.packageList.packagelist.status
    };
};
 
const mapDispatchToProps = (dispatch) => {
    return {
        packageRequest: (pn, pc, loginData) => {
            return dispatch(packageRequest(pn, pc, loginData));
        }
    };
};

export default connect(mapStateToProps, mapDispatchToProps)(MenuContainer);